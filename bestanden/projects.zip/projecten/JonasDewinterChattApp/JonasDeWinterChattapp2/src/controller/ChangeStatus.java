package controller;

import domain.Person;
import domain.PersonService;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet
public class ChangeStatus extends RequestHandler {
    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {

        String status =(String)request.getParameter("status");
        System.out.println(status);
        HttpSession session = request.getSession();
        Person persoon =(Person) session.getAttribute("user");
        persoon.setStatus(status);
        session.setAttribute("user",persoon);

        return "chatPagina.jsp";
    }



}
