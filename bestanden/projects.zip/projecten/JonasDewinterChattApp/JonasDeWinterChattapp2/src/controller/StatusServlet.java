package controller;

import domain.Person;
import domain.PersonService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/StatusServlet")
public class StatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    public StatusServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Person persoon =(Person)session.getAttribute("user");
        String statusJSON = this.toJSON(persoon.getStatus());
        System.out.println(statusJSON);
        response.setContentType("text/json");
        response.getWriter().write(statusJSON);
        session.setAttribute("user",persoon);
    }

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {

        String status =(String)request.getParameter("status");
        System.out.println(status);
        HttpSession session = request.getSession();
        Person persoon =(Person) session.getAttribute("user");
        persoon.setStatus(status);
        session.setAttribute("user",persoon);
    }

    private String toJSON (String status) {
        StringBuffer json = new StringBuffer();

        json.append("{ \"status\" : \"");
        json.append(status);
        json.append("\"}");

        return json.toString();
    }
}
