package controller;

import db.PersonRepositoryStub;
import domain.Person;
import domain.PersonService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/VriendenlijstServlet")
public class VriendenlijstServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public VriendenlijstServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Person persoon =(Person)session.getAttribute("user");
        StringBuffer json = new StringBuffer();
        json.append("[");
        for(Person vriend: persoon.getVrienden() ){
            String toevoegen = "";
            if(persoon.getVrienden().get(0) != vriend){
                toevoegen = ",";
            }
            toevoegen += this.toJSON(vriend);
            json.append(toevoegen);
        }
        json.append("]");
        String statusJSON= json.toString();
        System.out.println(statusJSON);
        response.setContentType("text/json");
        response.getWriter().write(statusJSON);
        session.setAttribute("user",persoon);
    }

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response) throws ServletException, IOException {

        String naam =(String)request.getParameter("naam");
        System.out.println(naam);
        HttpSession session = request.getSession();
        Person persoon =(Person) session.getAttribute("user");
        PersonService service = (PersonService) session.getAttribute("data");
        PersonRepositoryStub personen = service.getdata();
        persoon.addVriend(personen.getPersonByName(naam));
        session.setAttribute("user",persoon);
    }

    private String toJSON (Person vriend) {
        StringBuffer json = new StringBuffer();

        json.append("{ \"naam\" : \"");
        json.append(vriend.getFirstName());
        json.append("\", \"status\" : \"");
        json.append(vriend.getStatus());
        json.append("\"}");

        return json.toString();
    }
}
