package controller;

import db.PersonRepositoryStub;
import domain.Person;
import domain.PersonService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class addVriend extends RequestHandler{

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String naam =(String)request.getParameter("naam");
        HttpSession session = request.getSession();
        Person persoon =(Person) session.getAttribute("user");
        PersonService service = (PersonService) session.getAttribute("data");
        PersonRepositoryStub personen = service.getdata();
        persoon.addVriend(personen.getPersonByName(naam));
        session.setAttribute("user",persoon);
        return "chatPagina.jsp";
    }
}
