document.getElementById("body").onload = openSocket;

var webSocket;
var comment = document.getElementById("comments");

function openSocket(){
    webSocket = new WebSocket("ws://localhost:8080/echo");

    webSocket.onopen = function(event){
        writeResponse("Connection opened")
    };

    webSocket.onmessage = function(event){
        writeResponse(event.data);
    };

    webSocket.onclose = function(event){
        writeResponse("Connection closed");
    };
}

function sendPixar(){
    comment = document.getElementById("pixarComments");
    var naam = document.getElementById("Pixarnaam").value;
    var Comment = document.getElementById("PixarComment").value;
    var cijfer = document.getElementById("Pixarcijfer").value;
    webSocket.send(naam + ": " + Comment + " " + cijfer);
}

function sendProjectweek(){
    comment = document.getElementById("projectweekComments");
    var naam = document.getElementById("projectweeknaam").value;
    var Comment = document.getElementById("projectweekComment").value;
    var cijfer = document.getElementById("projectweekcijfer").value;
    webSocket.send(naam + ": " + Comment + " " + cijfer);
}

function sendPlan(){
    comment = document.getElementById("planComments");
    var naam = document.getElementById("plannaam").value;
    var Comment = document.getElementById("planComment").value;
    var cijfer = document.getElementById("plancijfer").value;
    webSocket.send(naam + ": " + Comment + " " + cijfer);
}

function sendMuziek(){
    comment = document.getElementById("muziekComments");
    var naam = document.getElementById("muzieknaam").value;
    var Comment = document.getElementById("muziekComment").value;
    var cijfer = document.getElementById("muziekcijfer").value;
    webSocket.send(naam + ": " + Comment + " " + cijfer);
}
function sendExamenvragen(){
    comment = document.getElementById("examenvragenComments");
    var naam = document.getElementById("examenvragennaam").value;
    var Comment = document.getElementById("examenvragenComment").value;
    var cijfer = document.getElementById("examenvragencijfer").value;
    webSocket.send(naam + ": " + Comment + " " + cijfer);
}

function closeSocket(){
    webSocket.close();
}

function writeResponse(text){
    comment.innerHTML += "<br/>" + text;
}