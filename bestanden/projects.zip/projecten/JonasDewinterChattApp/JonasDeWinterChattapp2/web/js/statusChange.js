document.getElementById("body").onload = getStatus;

var statusbutton = document.getElementById('StatusButton');
statusbutton.onclick = changeStatus;

var vriendbutton = document.getElementById("vriendButton");
vriendbutton.onclick = addVriend;

var getNewStatusRequest = new XMLHttpRequest();
var changeStatusRequest = new XMLHttpRequest();
var getNewVriendenRequest = new XMLHttpRequest();

function changeStatus(){
    var nieuweStatus = document.getElementById("Status").value;
    var info = "status=" + encodeURIComponent(nieuweStatus);

    changeStatusRequest.open("POST", "Controller?action=ChangeStatus", true);
    changeStatusRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    changeStatusRequest.send(info);
}

function getStatus() {
    getNewVriendenRequest.open("GET", "VriendenlijstServlet", true);
    getNewVriendenRequest.onreadystatechange = getVriendenData;
    getNewVriendenRequest.send(null);

    getNewStatusRequest.open("GET", "StatusServlet", true);
    getNewStatusRequest.onreadystatechange = getStatusData;
    getNewStatusRequest.send(null);
}

function getStatusData() {
    if (getNewStatusRequest.readyState === 4) {
        if (getNewStatusRequest.status === 200) {
            var serverResponse = JSON.parse(getNewStatusRequest.responseText);
            var statusXML = serverResponse.status;
            console.log()
            var StatusDiv = document.getElementById("nieuwsteStatus");
            var StatusParagraph = StatusDiv.childNodes[0];

            var statusText = document.createTextNode(statusXML);

            if (StatusParagraph == null) {
                StatusParagraph = document.createElement('p');
                StatusParagraph.id = "quoteText";
                StatusParagraph.appendChild(statusText);
                StatusDiv.appendChild(StatusParagraph);
            }
            else {
                StatusParagraph.removeChild(StatusParagraph.childNodes[0]);
                StatusParagraph.appendChild(statusText);
            }
            setTimeout("getStatus()", 1000);
        }
    }

}

function getVriendenData() {
    if (getNewVriendenRequest.readyState === 4) {
        if (getNewVriendenRequest.status === 200) {
            var weetikveel = getNewVriendenRequest.responseText;
            var serverResponse = JSON.parse(weetikveel);
            var vriendenDiv = document.getElementById("vriendenlijst");
            var vriendenParagraph = vriendenDiv.childNodes[0];


            if (vriendenParagraph == null) {
                vriendenParagraph = document.createElement('table');
                vriendenParagraph.id = "vriendenlijst";
                var lijstItem = document.createElement("tr");
                var naamLabel = document.createElement("th");
                var statusLabel = document.createElement("th");
                naamLabel.appendChild(document.createTextNode("naam"));
                statusLabel.appendChild(document.createTextNode("Status"));
                lijstItem.appendChild(naamLabel);
                lijstItem.appendChild(statusLabel);
                vriendenParagraph.appendChild(lijstItem);
            }

            for(var i = serverResponse.length - 1; i >= 0; i--) {

                if(i + 1 < vriendenParagraph.childElementCount){
                    vriendenParagraph.removeChild(vriendenParagraph.childNodes[i+1]);
                }
                var tablelijn = document.createElement("tr");
                var naam = document.createElement("td");
                var status = document.createElement("td");
                var obj = serverResponse[i];
                var naamXML = obj.naam;
                var statusXML = obj.status;
                naam.appendChild(document.createTextNode(naamXML));
                status.appendChild(document.createTextNode(statusXML));
                tablelijn.appendChild(naam);
                tablelijn.appendChild(status);
                vriendenParagraph.appendChild(tablelijn);
                console.log(obj.status);
            }
            vriendenDiv.appendChild(vriendenParagraph);
            setTimeout("getStatus()", 1000);
        }
    }
}

function addVriend(){
    var nieuweStatus = document.getElementById("addVriend").value;
    var info = "naam=" + encodeURIComponent(nieuweStatus);

    changeStatusRequest.open("POST", "Controller?action=addVriend", true);
    changeStatusRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    changeStatusRequest.send(info);
}