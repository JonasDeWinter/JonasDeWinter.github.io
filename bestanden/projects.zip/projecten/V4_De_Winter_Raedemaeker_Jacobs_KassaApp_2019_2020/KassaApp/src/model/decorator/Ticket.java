package model.decorator;

/**
 * @Author We hebben alles samen gedaan
 **/

public abstract class Ticket {
    private String result = "";

    public String getTekst(){
        return result;
    }
}
