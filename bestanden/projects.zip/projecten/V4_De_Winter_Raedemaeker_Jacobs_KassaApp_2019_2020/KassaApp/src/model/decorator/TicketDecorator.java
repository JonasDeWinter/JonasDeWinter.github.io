package model.decorator;

/**
 * @Author We hebben alles samen gedaan
 **/

public abstract class TicketDecorator extends Ticket{

    public abstract String getTekst();
}
