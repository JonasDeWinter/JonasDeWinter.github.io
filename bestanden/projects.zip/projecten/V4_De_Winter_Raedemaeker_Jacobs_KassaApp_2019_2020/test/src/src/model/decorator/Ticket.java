package src.model.decorator;

public abstract class Ticket {
    private String result = "";

    public String getTekst(){
        return result;
    }
}
