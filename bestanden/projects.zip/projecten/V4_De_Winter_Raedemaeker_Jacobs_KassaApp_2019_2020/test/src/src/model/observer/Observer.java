package src.model.observer;
import model.Artikel;
import java.util.ArrayList;

public interface Observer {
    public void update(ArrayList<Artikel> artikels);
}
