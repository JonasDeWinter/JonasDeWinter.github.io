package src.model.state;
import model.Winkelkar;

public class OnHold implements StateInterface {

    private Winkelkar winkelkar;

        public OnHold(Winkelkar winkelkar){
            this.winkelkar=winkelkar;
        }

    @Override
    public void offHold() {
        this.winkelkar.setCurrentState(this.winkelkar.getActief());
    }
}
