package domain;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import com.sun.source.tree.AssertTree;
import org.junit.Test;

public class CirkelTest {
    private Punt middelpunt = new Punt(10, 20);
    private Punt zelfdeMiddelpunt = new Punt(10, 20);
    private Punt anderMiddelpunt = new Punt(5,10);
    private int straal = 10;
    private int zelfdeStraal = 10;
    private int anderestraal = 5;

    @Test
    public void cirkel_met_geldig_middelpunt_en_straal() {
        Cirkel cirkel = new Cirkel(middelpunt, straal);

        assertEquals(cirkel.getMiddelPunt(), middelpunt);
        assertEquals(cirkel.getStraal(),straal);
    }

    @Test(expected = DomainException.class)
    public void middelpunt_van_een_cirkel_mag_niet_null_zijn(){
        new Cirkel(null,straal);
    }

    @Test(expected = DomainException.class)
    public void straal_mag_niet_kleiner_zijn_dan_0(){
        new Cirkel(middelpunt,-1);
    }

    @Test(expected = DomainException.class)
    public void straal_mag_niet_gelijk_zijn_dan_0(){
        new Cirkel(middelpunt,0);
    }

    @Test
    public void twee_cirkels_zijn_gelijk_als_ze_zelfde_straal_en_middelpunt_hebben(){
        Cirkel cirkel = new Cirkel(middelpunt,straal);
        Cirkel zelfdeCirkel = new Cirkel(zelfdeMiddelpunt,zelfdeStraal);

        assertTrue(cirkel.equals(zelfdeCirkel));
    }

    @Test
    public void twee_cirkels_zijn_verschillend_als_de_tweede_cirkel_null_is(){
        Cirkel cirkel = new Cirkel(middelpunt,straal);

        assertFalse(cirkel.equals(null));
    }

    @Test
    public void twee_cirkels_zijn_verschillen_als_middelpunt_verschillend_is(){
        Cirkel cirkel = new Cirkel(middelpunt,straal);
        Cirkel andermiddelpunt = new Cirkel(anderMiddelpunt ,zelfdeStraal);

        assertFalse(cirkel.equals(andermiddelpunt));
    }

    @Test
    public void twee_cirkels_zijn_verschillen_als_straal_verschillend_is(){
        Cirkel cirkel = new Cirkel(middelpunt,straal);
        Cirkel straalverschilt = new Cirkel(zelfdeMiddelpunt ,anderestraal);

        assertFalse(cirkel.equals(straalverschilt));
    }
}
