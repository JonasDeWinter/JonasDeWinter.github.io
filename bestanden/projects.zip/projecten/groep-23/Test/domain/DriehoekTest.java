package domain;

import static org.junit.Assert.*;

import org.junit.Test;

public class DriehoekTest {
	private Punt Punt1 = new Punt(10, 20);
	private Punt zelfdeAlsPunt1 = new Punt(10, 20);
	private Punt verschillendVanPunt1 = new Punt(15, 20);
	private Punt Punt2 = new Punt(20, 40);
	private Punt zelfdeAlsPunt2 = new Punt(20, 40);
	private Punt verschillendVanPunt2 = new Punt(40, 20);
	private Punt Punt3 = new Punt(190, 30);
	private Punt zelfdeAlsPunt3 = new Punt(190, 30);
	private Punt verschillendVanPunt3 = new Punt(120, 100);

	@Test
	public void Driehoek_moet_DrieHoek_aanmaken_met_gegeven_hoekPunten() {
		Driehoek drieHoek = new Driehoek(Punt1, Punt2, Punt3);

		//normaal was het HoekPunt ma ok
		assertEquals(Punt1, drieHoek.getHoekPunt1());
		assertEquals(Punt2, drieHoek.getHoekPunt2());
		assertEquals(Punt3, drieHoek.getHoekPunt3());
	}
	
	@Test (expected = DomainException.class)
	public void Driehoek_Moet_exception_gooien_als_hoekPunt1_null()  {
		new Driehoek(null, Punt2, Punt3);
	}
	
	@Test (expected = DomainException.class)
	public void Driehoek_Moet_exception_gooien_als_hoekPunt2_null()  {
		new Driehoek(Punt1, null, Punt3);
	}
	
	@Test (expected = DomainException.class)
	public void DrieHoek_Moet_exception_gooien_als_hoekPunt3_null()  {
		new Driehoek(Punt1, Punt2, null);
	}
	
	@Test
	public void equals_moet_false_teruggeven_als_hoekPunt1_verschillend(){
		Driehoek drieHoek = new Driehoek(Punt1, Punt2, Punt3);
		Driehoek andereDriehoek = new Driehoek(verschillendVanPunt1, zelfdeAlsPunt2, zelfdeAlsPunt3);
		assertFalse(drieHoek.equals(andereDriehoek));
	}
	
	@Test
	public void equals_moet_false_teruggeven_als_hoekPunt2_verschillend(){
		Driehoek drieHoek = new Driehoek(Punt1, Punt2, Punt3);
		Driehoek andereDriehoek = new Driehoek(zelfdeAlsPunt1, verschillendVanPunt2, zelfdeAlsPunt3);
		assertFalse(drieHoek.equals(andereDriehoek));
	}
	
	@Test
	public void equals_moet_false_teruggeven_als_hoekPunt3_verschillend(){
		Driehoek drieHoek = new Driehoek(Punt1, Punt2, Punt3);
		Driehoek andereDriehoek = new Driehoek(zelfdeAlsPunt1, zelfdeAlsPunt2, verschillendVanPunt3);
		assertFalse(drieHoek.equals(andereDriehoek));
	}
	
	@Test
	public void equals_moet_false_teruggeven_als_parameter_null(){
		Driehoek drieHoek = new Driehoek(Punt1, Punt2, Punt3);
		assertFalse(drieHoek.equals(null));
	}

	@Test
	public void bekijk_als_sorteer_wel_sorteert_321() {
		Driehoek verkeerdVolgorde = new Driehoek(Punt3, Punt2, Punt1);

		verkeerdVolgorde.sorteerHoekPunten();

		assertTrue(verkeerdVolgorde.getHoekPunt1().equals(Punt1));
		assertTrue(verkeerdVolgorde.getHoekPunt2().equals(Punt2));
		assertTrue(verkeerdVolgorde.getHoekPunt3().equals(Punt3));

	}
	@Test
	public void bekijk_als_sorteer_wel_sorteert_231() {
		Driehoek verkeerdVolgorde = new Driehoek(Punt2, Punt3, Punt1);

		verkeerdVolgorde.sorteerHoekPunten();

		assertTrue(verkeerdVolgorde.getHoekPunt1().equals(Punt1));
		assertTrue(verkeerdVolgorde.getHoekPunt2().equals(Punt2));
		assertTrue(verkeerdVolgorde.getHoekPunt3().equals(Punt3));

	}

	@Test
	public void bekijk_als_sorteer_wel_sorteert_123() {
		Driehoek verkeerdVolgorde = new Driehoek(Punt1, Punt2, Punt3);

		verkeerdVolgorde.sorteerHoekPunten();

		assertTrue(verkeerdVolgorde.getHoekPunt1().equals(Punt1));
		assertTrue(verkeerdVolgorde.getHoekPunt2().equals(Punt2));
		assertTrue(verkeerdVolgorde.getHoekPunt3().equals(Punt3));

	}

}
