package domain;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class TekeningHangManTest {

    @Test
    public void toevoegen_heeft_geen_effect(){
        assertTrue(true);
    }

    @Test
    public void verwijderen_heeft_geen_effect(){
        assertFalse(false);
    }
}
