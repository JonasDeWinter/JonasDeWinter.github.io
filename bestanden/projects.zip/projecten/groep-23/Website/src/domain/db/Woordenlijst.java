package domain.db;

import domain.model.Woord;

import java.util.ArrayList;

public class Woordenlijst {
    private ArrayList<Woord> woorden = new ArrayList<>();

    public Woordenlijst()
    {
        Woord sandaal=new Woord("sandaal","beginner");
        Woord projectweek=new Woord("projectweek","expert");
        Woord overerving=new Woord("overerving","expert");
        Woord test_first_development=new Woord("test first development","expert");
        Woord IllegalArgumentException=new Woord("IllegalArgumentException","expert");
        woorden.add(sandaal);
        woorden.add(projectweek);
        woorden.add(overerving);
        woorden.add(test_first_development);
        woorden.add(IllegalArgumentException);
    }

    public int getAantal() {
        return this.woorden.size();
    }

    public String getLangsteNaam(){
        Woord langste = woorden.get(0);
        for(Woord woord:woorden){
            if (woord.getLength() > langste.getLength()){
                langste = woord;
            }
        }
        return langste.toString();
    }
    public String getKortsteNaam(){
        Woord kortste = woorden.get(0);
        for(Woord woord:woorden){
            if (woord.getLength() < kortste.getLength()){
                kortste = woord;
            }
        }
        return kortste.toString();
    }


    public ArrayList<Woord> getWoorden() {
        return woorden;
    }

    public void setWoorden(ArrayList<Woord> woorden) {
        this.woorden = woorden;
    }

    public void voegToe(Woord woord)
    {
        woorden.add(woord);
    }


}
