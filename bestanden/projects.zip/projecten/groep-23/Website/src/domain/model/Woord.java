package domain.model;

public class Woord {

    private String woord;
    private String level;


    public Woord(String woord, String level) {
        if (woord.isEmpty() || woord == " ") {
            throw new IllegalArgumentException("waarde mag niet leeg zijn");
        } else {
            this.woord = woord;
            this.level = level;
        }
    }

    public String getWoord() {
        return woord;
    }

    public void setWoord(String woord) {
        this.woord = woord;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public int getLength()
    {
        return this.woord.length();
    }

    public String toString(){
        return this.woord;
    }
}

