package ui.controller;


import domain.db.Woordenlijst;
import domain.model.Woord;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet("/Overzicht")
public class Overzicht extends HttpServlet {
    Woordenlijst woordenlijst = new Woordenlijst();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        processRequest(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
    private void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = "home";
        if (request.getParameter("command") != null) {
            command = request.getParameter("command");

        }
        String destination;
        switch (command) {
            case "home":
                destination= home(request,response);
                break;
            case "download":
                destination=download(request,response);
                break;
            case "overview":
                destination = overview(request, response);
                break;
            case "add":
                destination=add(request,response);
                break;

            default:

                destination = home(request, response);
        }
        request.getRequestDispatcher(destination).forward(request, response);
    }
    private String home(HttpServletRequest request, HttpServletResponse response) {
        request.setAttribute("aantalWoorden",this.woordenlijst.getAantal());
        request.setAttribute("langsteWoord",this.woordenlijst.getLangsteNaam());
        request.setAttribute("KortsteWoord",this.woordenlijst.getKortsteNaam());


        return "index.jsp";
    }
    private String overview(HttpServletRequest request, HttpServletResponse response) {



            request.setAttribute("woordenlijst", this.woordenlijst);


        return "overzicht.jsp";
    }

    private String add(HttpServletRequest request, HttpServletResponse response) {
        String woord= request.getParameter("woord");
        String niveau=request.getParameter("niveau");
        Woord w = new Woord(woord, niveau);

            Woord woord1 = new Woord(woord,niveau);
            woordenlijst.voegToe(woord1);

            return overview(request,response);



    }

    private String download(HttpServletRequest request, HttpServletResponse response) {

        String filename = "woorden.txt";
        response.setContentType("APPLICATION/OCTET-STREAM");
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
        PrintWriter out = null;
        try {
            out = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (Woord woord : woordenlijst.getWoorden())
            out.println(woord.getWoord());
        out.close();
        return "index.jsp";

    }
}
