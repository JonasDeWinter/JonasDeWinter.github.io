package domain;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;


import java.util.Objects;
import javafx.scene.paint.*;

public class Cirkel extends Vorm implements Drawable{
    private Punt middelPunt;
    private int straal;

    public Cirkel(Punt middelPunt, int straal){
        setMiddelPunt(middelPunt);
        setStraal(straal);
    }

    public Punt getMiddelPunt() {
        return middelPunt;
    }

    private void setMiddelPunt(Punt middelPunt) {
        if(middelPunt == null)throw new DomainException("middelpunt mag niet leeg zijn");
        this.middelPunt = middelPunt;
    }

    public int getStraal() {
        return straal;
    }

    private void setStraal(int straal) {
        if(straal <= 0)throw new DomainException("straal moet groter zijn dan 0");
        this.straal = straal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cirkel cirkel = (Cirkel) o;
        if (this == cirkel){
            return true;
        }else if (cirkel.straal != this.straal){
            return false;
        }else if(cirkel == null){
            return false;
        }
        return straal == cirkel.straal &&
                Objects.equals(middelPunt, cirkel.middelPunt);
    }

    public String toString(){
        return " cirkel: middelpunt: " + getMiddelPunt().toString() + " - straal: " + straal+ "\n" + super.toString();
    }

    public Omhullende getOmhullende(){
        Punt linksboven = new Punt(middelPunt.getX()- straal,middelPunt.getY() - straal);
        Omhullende omhullende = new Omhullende(linksboven, straal*2, straal*2);

        return omhullende;
    }

    @Override
    public void teken(Pane root) {
        Circle cirkel = new Circle(this.getMiddelPunt().getX(),this.getMiddelPunt().getY(),this.getStraal());
        cirkel.setFill(this.getKleur());
        cirkel.setStroke(Color.BLACK);
        root.getChildren().add(cirkel);

    }
}
