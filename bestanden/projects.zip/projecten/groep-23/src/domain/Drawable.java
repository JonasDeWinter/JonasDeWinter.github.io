package domain;


import javafx.scene.layout.Pane;

public interface Drawable {

    default void teken(Pane root) {

    }

}