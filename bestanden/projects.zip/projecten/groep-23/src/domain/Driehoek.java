package domain;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polyline;
import ui.PuntApp;
import domain.Punt;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

public class Driehoek extends Vorm implements Drawable{
    private Punt hoekPunt1;
    private Punt hoekPunt2;
    private Punt hoekPunt3;

    public Driehoek(Punt hoekPunt1, Punt hoekPunt2, Punt hoekPunt3) {
        setHoekPunt1(hoekPunt1);
        setHoekPunt2(hoekPunt2);
        setHoekPunt3(hoekPunt3);
        sorteerHoekPunten();
    }

    public void setHoekPunt1(Punt hoekPunt1) {
        if(hoekPunt1 == null)
        {
            throw new DomainException("Punt 1 moet een geldig Punt zijn");
        }
        this.hoekPunt1 = hoekPunt1;
    }

    public void setHoekPunt2(Punt hoekPunt2) {
        if(hoekPunt2 == null)
        {
            throw new DomainException("Punt 2 moet een geldig Punt zijn");
        }
        this.hoekPunt2 = hoekPunt2;
    }

    public void setHoekPunt3(Punt hoekPunt3) {
        if(hoekPunt3 == null)
        {
            throw new DomainException("Punt 3 moet een geldig Punt zijn");
        }
        this.hoekPunt3 = hoekPunt3;
    }

    public Punt getHoekPunt1() {
        return hoekPunt1;
    }

    public Punt getHoekPunt2() {
        return hoekPunt2;
    }

    public Punt getHoekPunt3() {
        return hoekPunt3;
    }

    private boolean liggenOp1Lijn(Punt hoekPunt1, Punt hoekPunt2, Punt hoekPunt3)
    {
        int getal1 = (hoekPunt2.getX() - hoekPunt1.getX())*(hoekPunt3.getY()-hoekPunt1.getY());
        int getal2 = (hoekPunt3.getX() - hoekPunt1.getX())*(hoekPunt2.getY()-hoekPunt1.getY());
        if(getal1 == getal2)
        {
            return true;
        }
        return false;
    }

    public void sorteerHoekPunten() {
        ArrayList<Punt> Punten = new ArrayList<>();
        Punten.add(hoekPunt1);
        Punten.add(hoekPunt2);
        Punten.add(hoekPunt3);
        Punt hulp;


        for(int j = 0; j != 2; j++) {
            for (int i = 0; i != Punten.size(); i++) {
                if (i + 1 != 3) {
                    if (Punten.get(i).compareTo(Punten.get(i + 1)) == 1) {
                        hulp = Punten.get(i);
                        Punten.set(i, Punten.get(i + 1));
                        Punten.set(i + 1, hulp);
                    }
                }
            }
        }

        hoekPunt1 = Punten.get(0);
        hoekPunt2 = Punten.get(1);
        hoekPunt3 = Punten.get(2);

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Driehoek driehoek = (Driehoek) o;
        return hoekPunt1 == driehoek.hoekPunt1 &&
                hoekPunt2 == driehoek.hoekPunt2 &&
                hoekPunt3 == driehoek.hoekPunt3;
    }


    @Override
    public String toString() {
        return "Driehoek: " +
                "hoekPunt1: " + hoekPunt1 +
                ", hoekPunt2: " + hoekPunt2 +
                ", hoekPunt3: " + hoekPunt3 + "\n" + super.toString();
    }

    @Override
    public Omhullende getOmhullende() {
        Punt linksBoven;
        if(hoekPunt1.getY() <= hoekPunt2.getY()){
            if(hoekPunt1.getY() < hoekPunt3.getY()){
                linksBoven = new Punt (hoekPunt1.getX(),hoekPunt1.getY());
            }else {
                linksBoven = new Punt(hoekPunt1.getX(), hoekPunt3.getY());
            }
        }else if(hoekPunt2.getY() <= hoekPunt3.getY()){
            linksBoven = new Punt (hoekPunt1.getX(),hoekPunt2.getY());
        }else{
            linksBoven = new Punt (hoekPunt1.getX(),hoekPunt3.getY());
        }

        int grootsteY = 0;
        if(hoekPunt1.getY() >= hoekPunt2.getY()){
            if(hoekPunt1.getY() > hoekPunt3.getY()){
                grootsteY = hoekPunt1.getY();
            }
        }else if(hoekPunt2.getY() >= hoekPunt3.getY()){
            grootsteY = hoekPunt2.getY();
        }else{
            grootsteY = hoekPunt1.getY();
        }


        Omhullende omhullende  = new Omhullende(linksBoven, hoekPunt3.getX()- hoekPunt1.getX(), Math.abs(grootsteY- linksBoven.getY()));
        return omhullende;
    }

    @Override
    public void teken(Pane root) {
        Polyline driehoek = new Polyline();
        driehoek.getPoints().addAll(new Double[]{(double) this.getHoekPunt1().getX(), (double) this.getHoekPunt1().getY(), (double) this.getHoekPunt2().getX(),
                (double) this.getHoekPunt2().getY(), (double) this.getHoekPunt3().getX(), (double) this.getHoekPunt3().getY()});
        driehoek.setFill(this.getKleur());
        driehoek.setStroke(Color.BLACK);
        root.getChildren().add(driehoek);
    }
}
