package domain;

public class HangMan {
    private Speler speler;
    private TekeningHangMan tekeningHangMan;
    private WoordenLijst woordenLijst;
    private HintWoord hintWoord;
    private boolean gewonnen;

    public HangMan(Speler speler,WoordenLijst woordenlijst){
        setWoordenLijst(woordenlijst);
        setSpeler(speler);
        tekeningHangMan = new TekeningHangMan();
        gewonnen = false;
        hintWoord = new HintWoord(woordenlijst.getRandomWoord());
    }

    public void setWoordenLijst(WoordenLijst woordenLijst) {
        if(woordenLijst== null)throw new DomainException("woordenlijst mag niet leeg zijn");
        if(woordenLijst.getAantalWoorden() == 0) throw new DomainException("woordenlijst mag niet leeg zijn");
        this.woordenLijst = woordenLijst;

    }

    public Speler getSpeler() {
        return speler;
    }

    public void setSpeler(Speler speler) {
        if (speler == null) throw new DomainException("speler mag niet leeg zijn");
        this.speler = speler;
    }

    public TekeningHangMan getTekening() {
        return tekeningHangMan;
    }

    public String getHint(){
        return hintWoord.toString();
    }

    public boolean isGameOver(){
        if (this.tekeningHangMan.getAantalOnzichtbaar() == 0) {
            return true;
        }
        return false;

    }

    public boolean isGewonnen(){
        return hintWoord.isGeraden();
    }

    public boolean raad(char letter){

        if(this.hintWoord.raad(letter)){
            if(this.isGewonnen()){
                gewonnen = true;
            }
            return true;
        }else{
            tekeningHangMan.zetVolgendeZichtbaar();
            return false;
        }
    }
}
