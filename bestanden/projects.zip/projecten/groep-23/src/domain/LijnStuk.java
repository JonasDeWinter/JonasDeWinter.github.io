package domain;

import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;

import java.util.Objects;

public class LijnStuk extends Vorm implements Drawable{
    private Punt startPunt;
    private Punt eindPunt;

    public LijnStuk(Punt startPunt, Punt eindPunt){
        setStartPuntEnEindPunt(startPunt,eindPunt);
    }

    public Punt getStartPunt() {
        return startPunt;
    }

    public Punt getEindPunt() {
        return eindPunt;
    }

    public void setStartPuntEnEindPunt(Punt startPunt, Punt eindPunt) {
        if(startPunt == null) throw new DomainException("");
        if(eindPunt == null) throw new  DomainException("");
        if(eindPunt.equals(startPunt))throw new DomainException("de punten mogen niet gelijk zijn aan elkaar");
        this.startPunt = startPunt;
        this.eindPunt = eindPunt;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LijnStuk lijnStuk = (LijnStuk) o;
        if (this.getEindPunt().equals(lijnStuk.getStartPunt())){
            if (this.getStartPunt().equals(lijnStuk.getEindPunt())){
                return true;
            }
        }
        return Objects.equals(startPunt, lijnStuk.startPunt) &&
                Objects.equals(eindPunt, lijnStuk.eindPunt);
    }

    public String toString(){
        return "Lijn: startpunt: " + this.startPunt.toString() + " - eindpunt: " + this.eindPunt.toString() + "\n" + super.toString();
    }

    public Omhullende getOmhullende(){
        Punt linksboven;
        int x;
        int y;
        if(startPunt.getX() < eindPunt.getX()){
             x =  startPunt.getX();
        }else{
            x = eindPunt.getX();
        }

        if(startPunt.getY() < eindPunt.getY()){
            y =  startPunt.getY();
        }else{
            y = eindPunt.getY();
        }

        linksboven = new Punt(x,y);
        Omhullende omhullende = new Omhullende(linksboven,Math.abs(startPunt.getX()-eindPunt.getX()),Math.abs(startPunt.getY()- eindPunt.getY()));
        return omhullende;
    }

    @Override
    public void teken(Pane root) {
        Line lijnstuk = new Line(this.getStartPunt().getX(), this.getStartPunt().getY(), this.getEindPunt().getX(), this.getEindPunt().getY());
        lijnstuk.setStrokeWidth(4);
        root.getChildren().add(lijnstuk);

    }
}
