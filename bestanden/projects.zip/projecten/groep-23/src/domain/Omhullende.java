package domain;

import java.util.Objects;

public class Omhullende {
    private Punt positieLinksBoven;
    private int breedte;
    private int hoogte;

    public Omhullende(Punt positie, int breedte, int hoogte){
        setPositieLinksBoven(positie);
        setBreedte(breedte);
        setHoogte(hoogte);
    }

    public Punt getLinkerBovenhoek() {
        return positieLinksBoven;
    }

    public void setPositieLinksBoven(Punt positieLinksBoven) {
        if(positieLinksBoven == null)throw new DomainException("positielinksboven mag niet leeg zijn");
        this.positieLinksBoven = positieLinksBoven;
    }

    public int getBreedte() {

        return breedte;
    }

    public void setBreedte(int breedte) {
        if(breedte < 0)throw new DomainException("Breedte moet groter of gelijk aan 0 zijn");
        this.breedte = breedte;
    }

    public int getHoogte() {
        return hoogte;
    }

    public void setHoogte(int hoogte) {
        if(hoogte < 0)throw new DomainException("Hoogte moet groter of gelijk aan 0 zijn");
        this.hoogte = hoogte;
    }

    public int getMinimumX(){
        return positieLinksBoven.getX() ;
    }

    public int getMinimumY(){
        return positieLinksBoven.getY();
    }

    public int getMaximumX(){
        return positieLinksBoven.getX() + breedte;
    }

    public int getMaximumY(){
        return positieLinksBoven.getY() + hoogte;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Omhullende that = (Omhullende) o;
        return breedte == that.breedte &&
                hoogte == that.hoogte &&
                Objects.equals(positieLinksBoven, that.positieLinksBoven);
    }

    public String toString(){
        return "Omhullende: " + positieLinksBoven.toString() + " - "+ breedte + " - "+ hoogte;
    }
}
