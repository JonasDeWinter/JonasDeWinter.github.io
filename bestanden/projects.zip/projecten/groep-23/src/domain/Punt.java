package domain;

import java.util.Objects;

public class Punt {

    private int x;
    private int y;

    public Punt(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Punt punt = (Punt) o;
        return x == punt.x &&
                y == punt.y;
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }

    public int compareTo(Punt punt)
    {
        if(this.x == punt.x){
            if(this.y < punt.y){
                return 1;
            }else if(this.y == punt.y){
                return 0;
            }else{
                return -1;
            }
        }else if(this.x <= punt.x) {
            return -1;
        }else {
            return 1;
        }

    }

}
