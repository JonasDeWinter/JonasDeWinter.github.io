package domain;

import com.sun.jdi.VoidValue;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.Objects;

public class Rechthoek extends Vorm implements Drawable{
    private int breedte;
    private int hoogte;
    private Punt linkerBovenhoek;

    public Rechthoek( Punt linkerBovenhoek, int breedte, int hoogte) {
        setBreedte(breedte);
        setHoogte(hoogte);
        setLinkerBovenhoek(linkerBovenhoek);
    }

    public void setBreedte(int breedte) {
        if(breedte <= 0)
        {
            throw new DomainException("Breedte is kleiner dan 0");
        }
        this.breedte = breedte;
    }

    public void setHoogte(int hoogte) {
        if(hoogte <= 0)
        {
            throw new DomainException("Hoogte is kleiner dan 0");
        }
        this.hoogte = hoogte;
    }

    public void setLinkerBovenhoek(Punt linkerBovenhoek) {
        if(linkerBovenhoek == null)
        {
            throw new DomainException("Het punt is onbestaand");
        }
        this.linkerBovenhoek = linkerBovenhoek;
    }

    public int getBreedte() {
        return breedte;
    }

    public int getHoogte() {
        return hoogte;
    }

    public Punt getLinkerBovenhoek() {
        return linkerBovenhoek;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Rechthoek rechthoek = (Rechthoek) o;
        return breedte == rechthoek.breedte &&
                hoogte == rechthoek.hoogte &&
                Objects.equals(linkerBovenhoek, rechthoek.linkerBovenhoek);
    }


    @Override
    public String toString() {
        return "Rechthoek: linkerbovenhoek:(" + linkerBovenhoek.getX() + ", " + linkerBovenhoek.getY() + ") - breedte: " + breedte
                + " - hoogte: " + hoogte + "\n" + super.toString();
    }

    public Omhullende getOmhullende(){
        Omhullende rechthoek = new Omhullende(linkerBovenhoek,breedte,hoogte);

        return rechthoek;
    }

    @Override
    public void teken(Pane root) {
        Rectangle rechthoek = new Rectangle(this.getLinkerBovenhoek().getX(), this.getLinkerBovenhoek().getY(), this.getBreedte(), this.getHoogte());
        rechthoek.setFill(this.getKleur());
        rechthoek.setStroke(Color.BLACK);
        root.getChildren().add(rechthoek);
    }
}
