package domain;

import java.util.Objects;

public class Speler {
    public String naam;
    private int score;

    public Speler(String naam){
        if(naam ==null) throw  new  DomainException("");
        if(naam.trim().isEmpty()) throw new DomainException("De naam van de speler is niet correct. \n De naam moet minstens 1 niet spatie bevatten");
        setNaam(naam);
        setScore(0);
    }


    public String getNaam() {
        return naam;
    }

    public int getScore() {
        return score;
    }

    public void addToScore(int score){
        this.score += score;
        if(this.score < 0) throw new DomainException("score mag niet negatief zijn");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Speler speler = (Speler) o;
        return score == speler.score &&
                Objects.equals(naam, speler.naam);
    }

    public String toString(){
        return getNaam() + " heeft als score " + getScore();
    }

    private void setNaam(String naam) {
        this.naam = naam;
    }

    private void setScore(int score) {
        this.score = score;
    }
}