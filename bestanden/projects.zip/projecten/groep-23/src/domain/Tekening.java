package domain;

import java.awt.*;
import java.util.ArrayList;
import domain.Vorm;
import javafx.scene.layout.Pane;

import java.util.List;
import java.util.Objects;

public class Tekening implements Drawable{
    private String naam;
    private List<Vorm> vormen;
    static final int MIN_X = 0;
    static final int MIN_Y = 0;
    static final int MAX_X = 399;
    static final int MAX_Y = 399;


    public Tekening(String naam) {
        setNaam(naam);
        vormen = new ArrayList<>();
    }

    public static boolean isValidNaam(String naam) {
        if (naam.trim().isEmpty()) {
            return false;
        } else if (naam == null) {
            return false;
        }
        return true;
    }

    public String getNaam() {
        return naam;
    }




    private void setNaam (String naam){
        if (naam == null) throw new IllegalArgumentException("naam mag niet leeg zijn");
        if (naam.trim().isEmpty()) throw new IllegalArgumentException("naam mag niet leeg zijn");
        this.naam = naam;
    }

    public void voegToe (Vorm vorm){
        if (vorm.equals(null)) {
            throw new IllegalArgumentException("vorm mag niet leeg zijn");
        } else if (bevat(vorm) == false) {
            if ((vorm.getOmhullende().getMinimumX() >= MIN_X && vorm.getOmhullende().getMaximumX() <= MAX_X) && (vorm.getOmhullende().getMinimumY() > MIN_Y && vorm.getOmhullende().getMaximumX() < MAX_Y)) {
                vormen.add(vorm);
            }else{
                throw new DomainException("De vorm past niet in het kader");
            }
        }
    }



    public Vorm getVorm ( int index){
        return vormen.get(index);
    }

    public int getAantalVormen () {
        return vormen.size();
    }

    public void verwijder (Vorm vorm){
        for (int i = 0; i != vormen.size(); i++) {
            if (getVorm(i).equals(vorm)) {
                vormen.remove(i);
                break;
            }
        }
    }
    public boolean bevat(Vorm vorm){

        if (vorm.equals(null)) throw new IllegalArgumentException("vorm mag niet leeg zijn");
        for (Vorm v : vormen) {
            if (vorm.equals(v)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean equals (Object o){
        boolean result = false;
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tekening tekening = (Tekening) o;
        if (this.getAantalVormen() != tekening.getAantalVormen()) {
            return false;
        } else {
            for (Vorm v : vormen) {
                for (Vorm w : tekening.vormen) {
                    if (v.equals(w)) {
                        result = true;
                        break;
                    } else {
                        result = false;
                    }
                }
                if (result == false) {
                    return false;
                }
            }
            return true;
        }
    }

    @Override
    public String toString () {
        return "Tekening: " +
                "naam: '" + naam + '\n' + printvormen();
    }

    private String printvormen () {
        String result = "";
        for (Vorm v : vormen) {
            result += v.toString() + "\n";
        }
        return result;
    }

    @Override
    public void teken(Pane root) {
        for (Vorm vorm: vormen) {
            if(vorm.isZichtbaar()){
                vorm.teken(root);
            }
        }

    }
}
