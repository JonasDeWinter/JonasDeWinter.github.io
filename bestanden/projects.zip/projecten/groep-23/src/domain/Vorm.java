package domain;


import javafx.scene.effect.ColorAdjust;

import javafx.scene.paint.*;


public abstract class Vorm implements Drawable{


    private boolean isZichtbaar = true;
    private Color kleur = Color.WHITE;

    public Color getKleur(){
        return kleur;
    }

    public void setKleur(Color kleur){
        this.kleur = kleur;
    }

    public abstract Omhullende getOmhullende();

    public boolean isZichtbaar(){
        return isZichtbaar;
    }

    public void setZichtbaar(boolean zet){
        this.isZichtbaar = zet;
    }

    public String toString(){
        return getOmhullende().toString();
    }



}
