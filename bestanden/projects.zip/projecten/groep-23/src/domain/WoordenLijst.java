package domain;

import java.util.ArrayList;
import java.util.List;

public class WoordenLijst {
    private List<String> woordenLijst;

    public WoordenLijst() {
        woordenLijst = new ArrayList<String>();
    }

    public int getAantalWoorden() {
        return woordenLijst.size();
    }

    //zinnen lukt nog niet
    public void voegToe(String woord){
        if(woord==null||woord.trim().isEmpty())
            throw new DomainException("Woord mag niet leeg zijn.");
        //woord dat er al in staat mag niet dubbel toegevoegd worden
        if(woordenLijst.contains(woord))
        {
            throw new DomainException("Dit woord staat er al in!");
        }
        else
        {
            woordenLijst.add(woord);
        }
    }

    public String getRandomWoord() {
        if(woordenLijst.size()==0) throw new DomainException("Geen woorden beschikbaar");
        int randomGetal = (int) Math.floor(Math.random() * (woordenLijst.size() - 1));
        return woordenLijst.get(randomGetal);
    }
}
