package ui;


import domain.*;
import javafx.scene.Group;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;

import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public class LijnstukApp {
    private Label  invoerXStartpuntLabelLijnstuk , invoerYStartpuntLabelLijnstuk , invoerYEindpuntLabelLijnstuk , invoerXEindpuntLabelLijnstuk ;
    private TextField invoerXStartpuntLijnstuk , invoerYStartpuntLijnstuk , invoerXEindpuntLijnstuk , invoerYEindpuntLijnstuk ;
    private Alert foutenboodschap = new Alert(Alert.AlertType.WARNING);

    private Vorm vorm;
    private Punt punt1,punt2;

    public LijnstukApp(GridPane root) {
        init(root,0);

        invoerYEindpuntLijnstuk .setOnAction(eventIngaveHoogte -> {
            try {
                punt1 = new Punt(Integer.parseInt(invoerXStartpuntLijnstuk .getText()), Integer.parseInt(invoerYStartpuntLijnstuk .getText()));
                punt2 = new Punt(Integer.parseInt(invoerXEindpuntLijnstuk .getText()), Integer.parseInt(invoerYEindpuntLijnstuk .getText()));
                vorm = new LijnStuk(punt1, punt2);


                root.getChildren().clear();

                Text uitvoer = new Text();
                uitvoer.setText(vorm.toString());
                root.add(uitvoer, 0, 0);
            } catch(NumberFormatException e){

                invoerYEindpuntLijnstuk .clear();

                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("Hoogte moet een geheel getal zijn!");
                foutenboodschap.showAndWait();
            }catch (DomainException e){
                invoerYEindpuntLijnstuk.clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setHeaderText(null);
                foutenboodschap.setContentText(e.getMessage());
                foutenboodschap.showAndWait();
            }
        });

    }
    public LijnstukApp(GridPane root, Tekening tekening){

        init(root,1);

        invoerYEindpuntLijnstuk .setOnAction(eventIngaveHoogte -> {
            try {
                punt1 = new Punt(Integer.parseInt(invoerXStartpuntLijnstuk .getText()), Integer.parseInt(invoerYStartpuntLijnstuk .getText()));
                punt2 = new Punt(Integer.parseInt(invoerXEindpuntLijnstuk .getText()), Integer.parseInt(invoerYEindpuntLijnstuk .getText()));
                vorm = new LijnStuk(punt1, punt2);

                tekening.voegToe(vorm);
                cleanUp(root);
            } catch(NumberFormatException e){

                invoerYEindpuntLijnstuk .clear();

                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("Hoogte moet een geheel getal zijn!");
                foutenboodschap.showAndWait();
            }catch (DomainException e){
                cleanUp(root);
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setHeaderText(null);
                foutenboodschap.setContentText(e.getMessage());
                foutenboodschap.showAndWait();
            }
        });
    }
    private void init(GridPane root, int teller){

        invoerXStartpuntLabelLijnstuk  = new Label("Geef de x-coördinaat van het startpunt ");
        invoerXStartpuntLijnstuk  = new TextField();
        invoerYStartpuntLabelLijnstuk  = new Label("Geef de y-coördinaat van het startpunt ");
        invoerYStartpuntLijnstuk  = new TextField();
        invoerXEindpuntLabelLijnstuk  = new Label ("Geef de x-coördinaat van het eindpunt ");
        invoerXEindpuntLijnstuk  = new TextField();
        invoerYEindpuntLabelLijnstuk  = new Label ("Geef de y-coördinaat van het eindpunt ");
        invoerYEindpuntLijnstuk  = new TextField();

        root.add(invoerXStartpuntLabelLijnstuk , 0, teller);
        root.add(invoerXStartpuntLijnstuk , 1, teller);

        invoerXStartpuntLijnstuk.setOnAction(eventInaveYstartpunt -> {
            try {
                Integer.parseInt(invoerXStartpuntLijnstuk .getText());
                root.add(invoerYStartpuntLabelLijnstuk , 0, teller + 1);
                root.add(invoerYStartpuntLijnstuk , 1, teller + 1);
            }
            catch(NumberFormatException e){
                invoerXStartpuntLijnstuk.clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("x coördinaat moet een geheel getal zijn");
                foutenboodschap.showAndWait();
            }
        });

        invoerYStartpuntLijnstuk .setOnAction(eventInaveYstartpunt -> {
            try {
                Integer.parseInt(invoerYStartpuntLijnstuk .getText());
                root.add(invoerXEindpuntLabelLijnstuk , 0, teller + 2);
                root.add(invoerXEindpuntLijnstuk , 1, teller + 2);
            }
            catch(NumberFormatException e){
                invoerYStartpuntLijnstuk .clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("x coördinaat moet een geheel getal zijn");
                foutenboodschap.showAndWait();
            }
        });

        invoerXEindpuntLijnstuk .setOnAction(eventInaveYstartpunt -> {
            try {
                Integer.parseInt(invoerXEindpuntLijnstuk .getText());
                root.add(invoerYEindpuntLabelLijnstuk , 0, teller + 3);
                root.add(invoerYEindpuntLijnstuk , 1, teller + 3);
            }
            catch(NumberFormatException e){
                invoerXEindpuntLijnstuk .clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("x coördinaat moet een geheel getal zijn");
                foutenboodschap.showAndWait();
            }
        });
    }

    private void  cleanUp(GridPane root){

        root.getChildren().remove(invoerXStartpuntLabelLijnstuk );
        root.getChildren().remove(invoerXStartpuntLijnstuk );
        root.getChildren().remove(invoerYStartpuntLabelLijnstuk );
        root.getChildren().remove(invoerYStartpuntLijnstuk );
        root.getChildren().remove(invoerYEindpuntLabelLijnstuk );
        root.getChildren().remove(invoerXEindpuntLijnstuk );
        root.getChildren().remove(invoerXEindpuntLabelLijnstuk );
        root.getChildren().remove(invoerYEindpuntLijnstuk );

    }
}
