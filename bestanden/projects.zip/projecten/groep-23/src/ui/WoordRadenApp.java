package ui;

import domain.Speler;
import domain.HintWoord;
import domain.HintLetter;
import db.domain.WoordenLezer;
import domain.WoordenLijst;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

import java.util.List;

public class WoordRadenApp {
    Speler speler;
    private Label welkWoordLabel, woordTeRadenLabel, invoerLetterLabel;
    private TextField invoerLetter;
    private Alert foutenboodschap = new Alert(Alert.AlertType.WARNING);

    private List<HintLetter> hintLetters;

    private int indexGeradenWoord = 4;

    private WoordenLezer lezen = new WoordenLezer("hangman.txt");
    WoordenLijst woordenlijst =  lezen.lees();
    String teRadenWoord = woordenlijst.getRandomWoord();
    int aantalGeraden;

    private HintWoord woordTeRaden = new HintWoord(teRadenWoord);

    public WoordRadenApp(GridPane root, Speler speler)
    {
        welkWoordLabel = new Label("Rarara, welk woord zoeken we?");
        woordTeRadenLabel = new Label(woordTeRaden.toString());
        invoerLetterLabel = new Label("Geef 1 letter");
        invoerLetter= new TextField();

        //dit is het woord dat te raden is

        root.add(welkWoordLabel, 0, 0);
        root.add(woordTeRadenLabel, 0, 1);
        root.add(invoerLetterLabel, 0, 2);
        root.add(invoerLetter, 0, 3);

        invoerLetter.setOnAction(eventIngaveLetter ->{
            HintLetter hintletter = new HintLetter(invoerLetter.getText().charAt(0));
            aantalGeraden++;
            if(woordTeRaden.raad(invoerLetter.getText().charAt(0)))
            {
                root.getChildren().clear();
                invoerLetter.clear();
                hintletter.toChar();
                woordTeRadenLabel = new Label(woordTeRaden.toString());
                root.add(welkWoordLabel, 0, 0);
                root.add(woordTeRadenLabel, 0, 1);
                root.add(invoerLetterLabel, 0, 2);
                root.add(invoerLetter, 0, 3);
                if(!woordTeRadenLabel.getText().contains("_"))
                {
                    foutenboodschap.setTitle("Warning");
                    foutenboodschap.setContentText("Proficiat, " + speler.naam + " je hebt het woord geraden in " + aantalGeraden + " keer!");
                    foutenboodschap.showAndWait();
                }

            }
            else
            {
                invoerLetter.clear();
                foutenboodschap.setTitle("Warning");
                foutenboodschap.setContentText("Deze letter zit niet in het woord!");
                foutenboodschap.showAndWait();
            }
        });

    }
}
