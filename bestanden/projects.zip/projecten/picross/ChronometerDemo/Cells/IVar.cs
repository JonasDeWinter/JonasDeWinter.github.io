﻿
namespace Cells
{
    public interface IVar<T>
    {
        T Value { get; set; }
    }
}
