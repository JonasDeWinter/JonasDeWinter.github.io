﻿using PiCross;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Utility;
using ViewModel;

namespace View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
             
            DataContext = new Navigator();
        }
    }

    public class Navigator : INotifyPropertyChanged
    {
        private Screen currentScreen;


        public Navigator()
        {
            this.PiCrossViewModel = new PiCrossViewModel();
            this.currentScreen = new IntroductionScreen(this);
        }

        public PiCrossViewModel PiCrossViewModel { get; }

        public Screen CurrentScreen
        {
            get
            {
                return currentScreen;
            }
            set
            {
                this.currentScreen = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CurrentScreen)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public abstract class Screen
    {
        protected readonly Navigator navigator;

        public PiCrossViewModel PiCrossViewModel { get; set; }
        protected Screen(Navigator navigator)
        {
            this.navigator = navigator;
            this.PiCrossViewModel = navigator.PiCrossViewModel;
        }

        protected void SwitchTo(Screen screen)
        {
            this.navigator.CurrentScreen = screen;
        }

    }

    public class IntroductionScreen : Screen
    {
        

        public IntroductionScreen(Navigator navigator) : base(navigator)
        {
            startApp = new NavigateCommand(() => SwitchTo(new SpelerSelectionScreen(navigator)));
        }

        public ICommand startApp { get; }
    }


    public class SpelerSelectionScreen : Screen
    {
        public SpelerSelectionScreen(Navigator navigator) : base(navigator)
        {
           
            GoToPuzzleSelectionScreen = new NavigateCommand(() => SwitchTo(new PuzzleSelectionScreen(navigator)));
        }

        public ICommand GoToPuzzleSelectionScreen { get; }
    }

    public class PuzzleSelectionScreen : Screen
    {
        public PuzzleSelectionScreen(Navigator navigator) : base(navigator)
        {
            GoToSpelerSelectionScreen = new NavigateCommand(() => SwitchTo(new SpelerSelectionScreen(navigator)));
            GoToPuzzleScreen = new NavigateCommand(() => SwitchTo(new PuzzleScreen(navigator)));
            PiCrossViewModel.login();
        }

        public ICommand GoToSpelerSelectionScreen { get; }
        public ICommand GoToPuzzleScreen { get; }
    }

    public class PuzzleScreen : Screen
    {
        private readonly DispatcherTimer timer;
        public PuzzleScreen(Navigator navigator) : base(navigator)
        {
            this.Chronometer = new Chronometer();
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(1);
            timer.Tick += (o, s) => Chronometer.Tick();
            timer.Start();
            Chronometer.Start();
            PiCrossViewModel.maakPuzzle();
            GoToPuzzleSelectionScreen = new NavigateCommand(() => SwitchTo(new PuzzleSelectionScreen(navigator)));
            start = new NavigateCommand(() => startTimer());
            pauze = new NavigateCommand(() => stopTimer());
            this.PiCrossViewModel.puzzle.IsSolved.ValueChanged += () => { if (PiCrossViewModel.puzzle.IsSolved.Value) { this.PuzzleKlaar(); } }; 
        }
        public void startTimer()
        {
            Chronometer.Start();
        }
        public void stopTimer()
        {
            Chronometer.Pause();
        }

        public void PuzzleKlaar()
        {
            Chronometer.Pause();
            var uri = new Uri(@"../../../../picrossSucces.mp3", UriKind.RelativeOrAbsolute);
            var player = new MediaPlayer();
            player.Open(uri);
            player.Play();
        }
        public Chronometer Chronometer { get; }
        public ICommand GoToPuzzleSelectionScreen { get; }
        public ICommand start { get; }
        public ICommand pauze { get; }
        
    }

    public class SquareConverter : IValueConverter

    {
        public object filled { get; set; }
        public object empty { get; set; }
        public object unknown { get; set; }
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var square = (Square)value;


            if (square == Square.EMPTY)
            {
                return empty;
            }
            else if (square == Square.FILLED)
            {
                return filled;
            }
            else
            {
                return unknown;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public class SolvedConverter : IValueConverter

    {
        public object solved { get; set; }
        public object unsolved { get; set; }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var opgelost = (bool)value;
            

            if (opgelost == true)
            {
                return solved;
            }
            else
            {
                return unsolved;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

