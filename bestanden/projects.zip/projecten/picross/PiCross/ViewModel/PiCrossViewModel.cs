﻿using Cells;
using DataStructures;
using PiCross;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Utility;

namespace ViewModel
{
    public class PiCrossViewModel
    {
        private PiCrossFacade facade;
        private IGameData gamedata;
        public IPlayablePuzzle puzzle { get; set; }
        public string SelectedPlayer { get; set; }
        public IPlayerProfile logedInPlayer { get; set; }
        public IPuzzleLibraryEntry SelectedPuzzle { get; set; }

        public IGrid<IPlayablePuzzleSquare> Grid { get; set; }

        public IGrid<IPlayablePuzzleSquare> showGrid { get; set; }
        public IGameData Gamedata
        {
            get
            {
                return gamedata;
            }
            set
            {
                this.gamedata = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Gamedata)));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public PiCrossViewModel()
        {
            facade = new PiCrossFacade();
            
            this.gamedata = facade.LoadGameData("../../../../python/picross.zip");
            Console.WriteLine(gamedata.PlayerDatabase.PlayerNames.Count);
            this.Gamedata = this.gamedata;
            Console.WriteLine(Gamedata.PlayerDatabase.PlayerNames.Count);
            
            addPlayer = new GameDataCommand(Gamedata);

        }
        public void login()
        {
            logedInPlayer = gamedata.PlayerDatabase[SelectedPlayer];
            Console.WriteLine(logedInPlayer);
        }

        public void maakPuzzle()
        {
            this.puzzle = facade.CreatePlayablePuzzle(SelectedPuzzle.Puzzle);
            this.Grid = puzzle.Grid;

            showGrid = this.Grid.Map((position, var) => new SquareViewModel(this, var.Contents, var.Position)).Copy();
            foreach (var row in Grid.Items.ToList())
            {
                Console.WriteLine(showGrid[row.Position].Position + " = " + row.Position);
            }
            
        }
        public GameDataCommand addPlayer { get; }


    }

    public class GameDataCommand : ICommand
    {


        private readonly IGameData gameData;
        public GameDataCommand( IGameData gameData)
        {
            this.gameData = gameData;
        }

        public event EventHandler CanExecuteChanged;

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            this.gameData.PlayerDatabase.CreateNewProfile((string)parameter);

        }
    }

   

}
