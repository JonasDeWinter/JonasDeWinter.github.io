﻿using Cells;
using DataStructures;
using PiCross;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ViewModel
{
    class SquareViewModel: IPlayablePuzzleSquare
    {
        public ICommand setEmpty { get; set; }
        public ICommand setFull { get; set; }

        public Cell<Square> Contents { get; }

        public Vector2D Position { get; }

        public SquareViewModel(PiCrossViewModel parent, Cell<Square> square, Vector2D position )
        {
            this.Contents = square;
            this.Position = position;
            setEmpty = new AddCommand(Contents, "left");
            setFull = new AddCommand(Contents, "right");
        }


    }
    public class AddCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private string click;
        private Cell<Square> square;
        public AddCommand(Cell<Square> square, String click)
        {
            this.square = square;
            this.click = click;
        }

        public bool CanExecute(object parameter)
        {
            return (click.Equals("left") || click.Equals("right"));
        }

        public void Execute(object parameter)
        {
            if (click.Equals("left"))
            {
                if (this.square.Value != Square.FILLED)
                {
                    this.square.Value = Square.FILLED;
                }
                else
                {
                    this.square.Value = Square.UNKNOWN;
                }
            }
            else
            {
                if (this.square.Value != Square.EMPTY)
                {
                    this.square.Value = Square.EMPTY;
                }
                else
                {
                    this.square.Value = Square.UNKNOWN;
                }
            }
        }
    }
}
