package ucll.project.db;

public class DatabaseException extends RuntimeException{

    public DatabaseException(String message){
        super(message);
    }
}
