package ucll.project.db;

import ucll.project.domain.ticket.Ticket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InMemoryTicketDB implements TicketDb{

    private Map<Integer, Ticket> ticketLijst;
    private int volgendeTicketNummer;

    public InMemoryTicketDB() {
        this.ticketLijst = new HashMap<Integer, Ticket>();
    }

    @Override
    public Ticket getTicket(int nr){
        Ticket ticket = null;
        for(Integer i : ticketLijst.keySet()){
            if(ticketLijst.get(i).getNr() == nr){
                ticket = ticketLijst.get(i);
                break;
            }
        }
        return ticket;
    }

    @Override
    public Ticket getTicket(String voornaam, String achternaam, String email) {
        Ticket ticket = null;
        for(Integer i : ticketLijst.keySet()){
            if(ticketLijst.get(i).getStudent().getVoornaam().equals(voornaam)
               && ticketLijst.get(i).getStudent().getAchternaam().equals(achternaam)
               && ticketLijst.get(i).getStudent().getEmail().equals(email)){
                ticket = ticketLijst.get(i);
                break;
            }
        }
        return ticket;
    }

    @Override
    public void addToTicketlist(Ticket ticket){
        ticketLijst.put(ticketLijst.size(),ticket);
    }

    public Ticket getVolgendeTicket(){
        if(getTickets().size() == 0 ) throw new IllegalArgumentException("er zijn geen tickets meer");
        Ticket eersteticket = getTickets().get(0);
        return eersteticket;
    }

    @Override
    public void deleteFromTicketlist(int nrTicket){
        int indexremove = 0;
        for(Integer i : ticketLijst.keySet()){
            if(ticketLijst.get(i).getNr() == nrTicket){
                ticketLijst.remove(i);
                indexremove = i;
                break;
            }
        }
        Map<Integer, Ticket> newMap = new HashMap<>();
        for (Integer i : ticketLijst.keySet()){
            if(i > indexremove){
                newMap.put(i-1,ticketLijst.get(i));
            }else{
                newMap.put(i,ticketLijst.get(i));
            }
        }
        this.ticketLijst = newMap;
    }

    public Map<Integer, Ticket> getHashMap(){
        return this.ticketLijst;
    }

    @Override
    public int size(){
        return ticketLijst.size();
    }

    @Override
    public int getVolgendeNr(){
        int nr = 0;
        for(Ticket t : ticketLijst.values()){
            nr = t.getNr();
        }
        return (nr+1);
    }

    @Override
    public List<Ticket> getTickets() {
        ArrayList<Ticket> arrayList = new ArrayList<Ticket>();
        for(Integer integer : ticketLijst.keySet()){
            arrayList.add(integer,ticketLijst.get(integer));
        }
        return arrayList;
    }

}
