package ucll.project.db;

import ucll.project.domain.ticket.Ticket;
import java.util.List;

public interface TicketDb {

    Ticket getTicket(int nr);

    Ticket getTicket(String voornaam, String achternaam, String email);

    void addToTicketlist(Ticket ticket);

    void deleteFromTicketlist(int nrTicket);

    int size();

    int getVolgendeNr();

    List<Ticket> getTickets();

    Ticket getVolgendeTicket();

}
