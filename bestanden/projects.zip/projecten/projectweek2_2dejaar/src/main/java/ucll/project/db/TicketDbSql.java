package ucll.project.db;

import ucll.project.domain.student.Student;
import ucll.project.domain.ticket.Diploma;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.ticket.Type;
import ucll.project.ui.controller.ControllerException;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TicketDbSql implements TicketDb{

    public TicketDbSql(){

    }

    @Override
    public Ticket getTicket(int nr) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT nr, voorinschrijving, type, diploma, studentvoornaam, studentachternaam, studentemail, tijd, nlvldiploma FROM ticketwachtrij WHERE nr = ?")){
            stmt.setInt(1,nr);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return ticketFromResult(rs);
                }
                return null;
            }
        }
        catch (SQLException exception){
            throw new DatabaseException(exception.getMessage());
        }
    }

    @Override
    public Ticket getTicket(String voornaam, String achternaam, String email) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT nr, voorinschrijving, type, diploma, studentvoornaam, studentachternaam, studentemail, tijd, nlvldiploma FROM ticketwachtrij WHERE studentvoornaam = ? AND studentachternaam = ? AND studentemail = ?;")){
            stmt.setString(1,voornaam);
            stmt.setString(2,achternaam);
            stmt.setString(3,email);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return ticketFromResult(rs);
                }
                return null;
            }
        }
        catch (SQLException exception){
            throw new DatabaseException(exception.getMessage());
        }
    }

    @Override
    public void addToTicketlist(Ticket ticket) {
        String sql = "INSERT INTO ticketwachtrij (nr, voorinschrijving, type, diploma, studentvoornaam, studentachternaam, studentemail, tijd, nlvldiploma) VALUES(?,?,?,?,?,?,?,?,?);";
        System.out.println("VOERT ADD UIT");
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1,ticket.getNr());
            stmt.setBoolean(2,ticket.isVoorinschrijving());
            stmt.setString(3,ticket.getType().toString());
            stmt.setString(4,ticket.getDiploma().toString());
            stmt.setString(5,ticket.getStudent().getVoornaam());
            stmt.setString(6,ticket.getStudent().getAchternaam());
            stmt.setString(7,ticket.getStudent().getEmail());
            stmt.setString(8,ticket.getTijd());
            stmt.setBoolean(9,ticket.isNederlandsVlaamsDiploma());
            stmt.execute();
        }
        catch (SQLException exception){
            throw new DatabaseException(exception.getMessage());
        }
    }

    @Override
    public void deleteFromTicketlist(int nr) {
        String sql = "DELETE FROM ticketwachtrij WHERE nr = ?;";
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)){
            statement.setInt(1,nr);
            statement.execute();
        }
        catch (SQLException exception){
            throw new DatabaseException(exception.getMessage());
        }
    }

    @Override
    public int size() {
        int size = 0;
        String sql = "SELECT COUNT(*) FROM ticketwachtrij";
        try (Connection conn = ConnectionPool.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet result = stmt.executeQuery(sql)) {
            while (result.next()){
                size = Integer.parseInt(result.getString("count"));
            }
        }
        catch (SQLException exception){
            throw new DatabaseException(exception.getMessage());
        }
        return size;
    }

    @Override
    public int getVolgendeNr() {
        if(getTickets().size() == 0 ) return 1;
        Ticket laatsteticket = getTickets().get(getTickets().size()-1);
        return laatsteticket.getNr()+1;
    }
    public Ticket getVolgendeTicket(){
        if(getTickets().size() == 0 ) throw new ControllerException("er zijn geen tickets meer");
        Ticket eersteticket = getTickets().get(0);
        return eersteticket;
    }

    @Override
    public List<Ticket> getTickets() {
        try (Connection conn = ConnectionPool.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet result = stmt.executeQuery("SELECT * FROM ticketwachtrij")) {
            List<Ticket> tickets = new ArrayList<>();
            while (result.next()) {
                tickets.add(ticketFromResult(result));
            }
            return tickets;
        } catch (SQLException exception) {
            throw new DatabaseException(exception.getMessage());
        }
    }

    private static Ticket ticketFromResult(ResultSet rs) throws SQLException{
        Ticket ticket = new Ticket();
        Student student = new Student();
        ticket.setNr(rs.getInt("nr"));
        student.setVoornaam(rs.getString("studentvoornaam"));
        student.setAchternaam(rs.getString("studentachternaam"));
        student.setEmail(rs.getString("studentemail"));
        ticket.setStudent(student);
        ticket.setVoorinschrijving(rs.getBoolean("voorinschrijving"));
        ticket.setType(Type.valueOf(rs.getString("type")));
        ticket.setDiploma(Diploma.valueOf(rs.getString("diploma")));
        ticket.setTijd(rs.getString("tijd"));
        ticket.setNederlandsVlaamsDiploma(rs.getBoolean("nlvldiploma"));
        return ticket;
    }

}
