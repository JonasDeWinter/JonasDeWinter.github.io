package ucll.project.domain.loket;

import ucll.project.domain.loket.Loket;
import ucll.project.domain.user.InvalidLogin;
import ucll.project.domain.user.User;

import java.util.List;

public interface LocketRepository {

    // CREATE
    void createLoket(Loket loket);

    // READ ONE
    Loket get(String loketnr);

    // READ ALL
    List<Loket> getAll();

    // UPDATE
    void update(Loket loket);

    // DELETE
    void delete(Loket loket);

}
