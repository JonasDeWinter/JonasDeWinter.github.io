package ucll.project.domain.loket;

import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.student.Student;
import ucll.project.domain.ticket.Ticket;

public class Loket {
    private String nr;
    private Medewerker medewerker;
    private boolean beschikbaar;
    private Student student;
    private Ticket ticket;

    // private String id;
    // private Ticket ticket;
    // private LoketStatus status;
    // private Medewerker medewerker;

    public Loket(String nr, Medewerker medewerker) {
        this.setNr(nr);
        this.setMedewerker(medewerker);
        this.setBeschikbaar(true);
    }

    public Loket(String nr, Medewerker medewerker, Student student) {
        this.setNr(nr);
        this.setMedewerker(medewerker);
        this.setStudent(student);
        this.setBeschikbaar(false);
    }


    public Loket(String nr) {
        this.setNr(nr);
        this.setBeschikbaar(true);
    }

    public Loket() {
        this.setBeschikbaar(true);
    }

    //Geen param want maar 1 student/balie
    public void verwijderStudent() {
        this.student = null;
    }

    public void verwijderMedewerker() {
        this.medewerker = null;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public void setTicket(Ticket ticket){this.ticket = ticket;}

    public Ticket getTicket(){return this.ticket;}

    public String getNr() {
        return nr;
    }

    public void setNr(String nr) {
        this.nr = nr;
    }

    public Medewerker getMedewerker() {
        return medewerker;
    }

    public void setMedewerker(Medewerker medewerker) {
        this.medewerker = medewerker;
    }

    public boolean isBeschikbaar() {
        return beschikbaar;
    }

    public void setBeschikbaar(boolean beschikbaar) {
        this.beschikbaar = beschikbaar;
    }

    public boolean getBeschikbaar() {
        return this.beschikbaar;
    }

    @Override
    public String toString() {
        return "Loket: " + "\n" +
                "nr: '" + nr + '\'' + "\n" +
                ", medewerker: " + medewerker + "\n" +
                ", beschikbaar: " + beschikbaar + "\n" +
                ", student: " + student + "\n";
    }

    public void verwijderTicket() {
        this.ticket = null;
    }
}