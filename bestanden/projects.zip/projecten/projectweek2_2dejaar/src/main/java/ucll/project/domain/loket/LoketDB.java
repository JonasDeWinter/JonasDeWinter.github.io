package ucll.project.domain.loket;

import ucll.project.db.ConnectionPool;
import ucll.project.domain.medewerker.AdministratiefMedewerker;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.student.Student;
import ucll.project.domain.user.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoketDB implements LocketRepository {

    @Override
    public void createLoket(Loket loket) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO \"loket\" " +
                             "(loketnr, medewerker, student, beschikbaar) VALUES (?, ?, ?, ?)", //TODO: AANPASSEN
                     Statement.RETURN_GENERATED_KEYS))
        {
            stmtSetLoket(stmt, 1, loket);
            if (stmt.executeUpdate() == 0) {
                throw new RuntimeException("Failed to create loket");
            }

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                generatedKeys.next();
                loket.setNr(generatedKeys.getString(1));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Loket get(String loketnr) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM \"loket\" WHERE loketnr = ?"))
        {
            stmt.setString(1, loketnr);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return LoketFromResult(rs);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Loket> getAll() {
        try (Connection conn = ConnectionPool.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM \"loket\""))
        {
            List<Loket> loketten = new ArrayList<>();
            while (rs.next()) {
                loketten.add(LoketFromResult(rs));
            }
            return loketten;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Loket loket) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("UPDATE \"loket\" SET " +
                     "loketnr = ?, medewerker = ?, student = ?, beschikbaar = ?" +
                     "WHERE loketnr = ? "))
        {
            int i = stmtSetLoket(stmt, 1, loket);
            stmt.setString(i, loket.getNr());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void delete(Loket loket) {
        try (Connection conn = ConnectionPool.getConnection();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM \"loket\" WHERE loketnr = ?"))
        {
            stmt.setString(1, loket.getNr());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private static Loket LoketFromResult(ResultSet rs) throws SQLException {
        Loket loket = new Loket();
        Student student = new Student();
        User user = new User();
        Medewerker medewerker = new AdministratiefMedewerker(user);
        loket.setMedewerker(medewerker);
        loket.setStudent(student);
        loket.setNr(rs.getString("loketnr"));
        loket.setBeschikbaar(rs.getBoolean("beschikbaar"));

        return loket;
    }

    private static int stmtSetLoket(PreparedStatement stmt, int i, Loket loket) throws SQLException {
        stmt.setString(i++, loket.getNr());
        stmt.setString(i++, loket.getMedewerker().getPersoon().getFirstName());
        stmt.setString(i++, loket.getStudent().getVoornaam());
        stmt.setBoolean(i++, loket.getBeschikbaar());
        return i;
    }

}
