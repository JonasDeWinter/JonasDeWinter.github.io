package ucll.project.domain.loket;

import ucll.project.domain.medewerker.AdministratiefMedewerker;
import ucll.project.domain.medewerker.JobStudent;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.student.Student;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

import java.util.ArrayList;

public class LoketDBInMemory {

    private ArrayList<Loket> loketten;

    public LoketDBInMemory() {
        loketten = new ArrayList<>();

        Loket loket = new Loket("A");
        Loket loket1 = new Loket("B");
        Loket loket2 = new Loket("C");
        Loket loket3 = new Loket("D");
        Loket loket4 = new Loket("E");
        loket.setBeschikbaar(true);
        loketten.add(loket);
        loketten.add(loket1);
        loketten.add(loket2);
        loketten.add(loket3);
        loketten.add(loket4);
    }

    public void addLoket(Loket loket){
        loketten.add(loket);
    }

    public Loket getLoket(String nr){
        Loket loket1 = null;
        for(Loket loket : loketten){
            if(loket.getNr().equalsIgnoreCase(nr)){
                loket1 = loket;
            }
        }
        return loket1;
    }

    public void removeLoket(Loket loket){
        loketten.remove(loket);
    }

    public void addStudentToLoket(Student student, Loket loket){
        loket.setStudent(student);
    }

    public void addTicketToLoket(Ticket ticket, Loket loket){loket.setTicket(ticket);}

    public void removeTicketFromLoket(Loket loket){
        loket.verwijderTicket();
    }

    public void removeStudentFromLoket(Loket loket){
        loket.verwijderStudent();
    }

    public void addMedewerkerToLoket(Medewerker medewerker, Loket loket){
        loket.setMedewerker(medewerker);
    }

    public void removeMedewerkerFromLoket(Loket loket){
        loket.verwijderMedewerker();
    }

    public ArrayList<Loket> getLoketten() {
        return loketten;
    }

    public void setLoketten(ArrayList<Loket> loketten) {
        this.loketten = loketten;
    }

    @Override
    public String toString() {
        String res = "";
        res += "Loketten: ";
        for(Loket loket : loketten){
            res += loket.toString();
        }
        return res;
    }

    public int size() {
        return this.loketten.size();
    }

    public Loket getEerstVrijLoket(){
        for(Loket loket : loketten){
            if(loket.isBeschikbaar()){
                return loket;
            }
        }
        return null;
    }
}
