package ucll.project.domain.loket;

import ucll.project.domain.DomainException;
import ucll.project.domain.loket.Loket;
import ucll.project.domain.loket.LoketDB;
import ucll.project.domain.loket.LoketDBInMemory;

import java.util.List;

public class LoketService {
    private LoketDBInMemory database;

    public LoketService(){
        database = new LoketDBInMemory();
    }

    public List<Loket> getLoketten(){
        return database.getLoketten();
    }

    public Loket getLoket(String nr){
        if(database.getLoket(nr) == null) throw new DomainException("Loket bestaat niet!");
        return database.getLoket(nr);
    }
    public Loket getVrijLoket(){
        return database.getEerstVrijLoket();
    }
}
