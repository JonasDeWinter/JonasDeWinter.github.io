package ucll.project.domain.loket;

public enum LoketStatus {
    BESCHIKBAAR,
    BEZIG,
    NIET_BESCHIKBAAR
}
