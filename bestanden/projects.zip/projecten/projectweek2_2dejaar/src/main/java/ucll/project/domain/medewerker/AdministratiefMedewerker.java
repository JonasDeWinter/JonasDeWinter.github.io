package ucll.project.domain.medewerker;

import ucll.project.domain.user.User;

public class AdministratiefMedewerker extends Medewerker {
    public AdministratiefMedewerker(User persoon) {
        super(persoon);
    }
}
