package ucll.project.domain.medewerker;

import ucll.project.domain.user.User;

public class JobStudent extends Medewerker {



    public JobStudent(User persoon) {
        super(persoon);
    }
}
