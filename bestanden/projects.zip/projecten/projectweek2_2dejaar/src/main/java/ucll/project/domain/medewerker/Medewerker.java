package ucll.project.domain.medewerker;

import ucll.project.domain.DomainException;
import ucll.project.domain.user.User;

public abstract class Medewerker {
    private User persoon;
    private MedewerkersStatus status;

    public Medewerker(User persoon) {
        this.persoon = persoon;
        setStatus(MedewerkersStatus.VRIJ);
    }

    public MedewerkersStatus getStatus() {
        return status;
    }

    public void setStatus(MedewerkersStatus status) {
        this.status = status;
    }

    public User getPersoon() {
        return persoon;
    }

    public void setPersoon(User persoon) {
        this.persoon = persoon;
    }


}
