package ucll.project.domain.medewerker;

import ucll.project.domain.student.Student;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

import java.util.ArrayList;
import java.util.HashMap;

public class MedewerkerFactory {

    HashMap<String, Medewerker> medewerkers = new HashMap<>();

    public void createNewStudent(String userName, String firstName, String lastName, String email, Gender gender, Role role){
        JobStudent jsd = new JobStudent(new User(userName, firstName, lastName, email, gender, role));
        medewerkers.put(jsd.getPersoon().getUserName(),jsd);
    }
    public void createNewStudent(User user){
        JobStudent jsd = new JobStudent(user);
        medewerkers.put(jsd.getPersoon().getUserName(),jsd);
    }
    public void createNewAdministratiefMedewerker(String userName, String firstName, String lastName, String email, Gender gender, Role role){
        AdministratiefMedewerker adm = new AdministratiefMedewerker(new User(userName,firstName,lastName,email,gender,role));
        medewerkers.put(adm.getPersoon().getUserName(), adm);
    }
    public void createNewAdministratiefMedewerker(User user){
        AdministratiefMedewerker adm = new AdministratiefMedewerker(user);
        medewerkers.put(adm.getPersoon().getUserName(), adm);
    }

    public Medewerker getFreeMedewerker(){
        for(String medewerker: medewerkers.keySet()){
            if (medewerkers.get(medewerker).getStatus() == MedewerkersStatus.VRIJ){
                return medewerkers.get(medewerker);
            }
        }
        return null;
    }

    public JobStudent getFreeJobstudent(){
        for(String medewerker: medewerkers.keySet()){
            if (medewerkers.get(medewerker).getStatus() == MedewerkersStatus.VRIJ && medewerkers.get(medewerker) instanceof JobStudent){
                return(JobStudent) medewerkers.get(medewerker);
            }
        }
        return null;
    }
    public AdministratiefMedewerker getFreeAdministratiefMedewerker(){
        for(String medewerker: medewerkers.keySet()){
            if (medewerkers.get(medewerker).getStatus() == MedewerkersStatus.VRIJ && medewerkers.get(medewerker) instanceof AdministratiefMedewerker){
                return(AdministratiefMedewerker) medewerkers.get(medewerker);
            }
        }
        return null;
    }
    public void changeMedewerkerStatus(Medewerker medewerker, MedewerkersStatus status){
        if (medewerkers.containsKey(medewerker.getPersoon().getUserName())){
            Medewerker medew = medewerkers.get(medewerker.getPersoon().getUserName());
            medew.setStatus(status);
            medewerkers.put(medewerker.getPersoon().getUserName(), medew);
        }
    }
    public HashMap<String, Medewerker> getAlleMedewerkers(){
        return medewerkers;
    }


}
