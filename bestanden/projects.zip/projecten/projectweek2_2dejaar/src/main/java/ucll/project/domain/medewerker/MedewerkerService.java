package ucll.project.domain.medewerker;

import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

import java.util.HashMap;
public class MedewerkerService {

    private MedewerkerFactory database;

    public MedewerkerService() {
        database = new MedewerkerFactory();
        User nick = new User("Nick", "Nick", "De Wyngaert", "nickdewyngaert@student.ucll.be", Gender.MALE, Role.SUPPORT);
        nick.hashAndSetPassword("NickDeWyngaert");
        database.createNewAdministratiefMedewerker(nick);

        User marko = new User("Marko", "Marko", "Kosmajac", "marko.kosmajac@student.ucll.be", Gender.MALE, Role.SUPPORT);
        marko.hashAndSetPassword("MarkoKosmajac");
        database.createNewAdministratiefMedewerker(marko);

        User max = new User("Max", "Max", "Van de Velde", "max.vandevelde@student.ucll.be", Gender.MALE, Role.SUPPORT);
        max.hashAndSetPassword("MaxVanDeVelde");
        database.createNewAdministratiefMedewerker(max);

        User simon = new User("Simon", "Simon", "Germeau", "simon.germeau@student.ucll.be", Gender.MALE, Role.SUPPORT);
        simon.hashAndSetPassword("SimonGermeau");
        database.createNewAdministratiefMedewerker(simon);

        User jonas = new User("Jonas", "Jonas", "De Winter", "jonas.dewinter@student.ucll.be", Gender.MALE, Role.SUPPORT);
        jonas.hashAndSetPassword("JonasDeWinter");
        database.createNewAdministratiefMedewerker(jonas);

        User arnaud = new User("Arnaud", "Arnaud", "Van Spauwen", "arnaud.vanspauwen@student.ucll.be", Gender.MALE, Role.SUPPORT);
        arnaud.hashAndSetPassword("ArnaudVanSpauwen");

        User ben = new User("Ben", "Ben", "Kada", "ben.kada@student.ucll.be", Gender.MALE, Role.SUPPORT);
        ben.hashAndSetPassword("BenKada");
        database.createNewAdministratiefMedewerker(ben);

        User yannick = new User("Yannick", "Yannick", "Delandmeter", "yannick.delandmeter@student.ucll.be", Gender.MALE, Role.SUPPORT);
        yannick.hashAndSetPassword("YannickDelandmeter");
        database.createNewAdministratiefMedewerker(yannick);
    }

    public HashMap<String,Medewerker> getAlleMedewerkers(){
        return database.getAlleMedewerkers();
    }

    public void addMedewerker(User x){
        this.database.createNewAdministratiefMedewerker(x);
    }
    public void addStudent(User x){
        this.database.createNewStudent(x);
    }
}
