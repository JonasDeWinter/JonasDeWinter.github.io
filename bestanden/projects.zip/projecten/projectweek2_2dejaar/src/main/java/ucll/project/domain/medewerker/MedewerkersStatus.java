package ucll.project.domain.medewerker;

public enum MedewerkersStatus {
    VRIJ,
    PAUZE,
    BEZET;
}
