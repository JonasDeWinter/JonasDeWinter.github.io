package ucll.project.domain.student;

import ucll.project.domain.DomainException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Student {
    private String voornaam,achternaam,email;
    private char eersteletterachternaam;

    public Student(){

    }


    public Student(String voornaam, String achternaam, String email) {
        setAchternaam(achternaam);
        setVoornaam(voornaam);
        setEmail(email);
    }

    public String getEersteLetterAchternaam(){
        return achternaam.substring(0,1);
    }

    public void setVoornaam(String voornaam) {
        if (voornaam == null || voornaam.trim().isEmpty()){
            throw new DomainException("Voornaam mag niet leeg zijn!");
        }
        this.voornaam = voornaam;
    }

    public String getVoornaam() {
        return this.voornaam;
    }

    public void setAchternaam(String achternaam) {
        if (achternaam == null || achternaam.trim().isEmpty()){
            throw new DomainException("Achternaam mag niet leeg zijn!");
        }
        this.achternaam = achternaam;
    }

    public String getAchternaam() {
        return this.achternaam;
    }


    public void setEmail(String email) {
        if(email.isEmpty()){
            throw new DomainException("No email given");
        }
        String USERID_PATTERN =
                "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern p = Pattern.compile(USERID_PATTERN);
        Matcher m = p.matcher(email);
        if (!m.matches()) {
            throw new DomainException("Email not valid");
        }
        this.email = email;
    }

    public String getEmail() {
        return this.email;
    }

    @Override
    public String toString() {
        return getAchternaam() + " " + getVoornaam() + "\n" + getEmail();
    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Student && ((Student) o).getAchternaam().equals(this.getAchternaam()) && ((Student) o).getVoornaam().equals(this.getVoornaam()));
    }
}
