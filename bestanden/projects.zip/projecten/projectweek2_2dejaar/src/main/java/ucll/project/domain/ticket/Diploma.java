package ucll.project.domain.ticket;

public enum Diploma {
    SECUNDAIR("Secundair"),
    BACHELOR("Bachelor"),
    MASTER("Master"),
    ANDERE("Andere");

    private final String val;

    Diploma(String val) {
        this.val = val;
    }

    public String getDiploma() {
        return val;
    }

}
