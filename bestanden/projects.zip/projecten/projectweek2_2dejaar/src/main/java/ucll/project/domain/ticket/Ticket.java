package ucll.project.domain.ticket;

import ucll.project.domain.DomainException;
import ucll.project.domain.student.Student;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Ticket {
    private int nr;
    private boolean voorinschrijving;
    private Type type;
    private Diploma diploma;
    private Student student;
    private String tijd;
    private boolean nederlandsVlaamsDiploma;

    public Ticket(){
        this.setNuTijd();
    }

    public Ticket(int nr, Student student, boolean voorinschrijving, Type type, Diploma diploma, boolean nederlandsVlaamsDiploma) {
        this.setNr(nr);
        this.setStudent(student);
        this.setVoorinschrijving(voorinschrijving);
        this.setType(type);
        this.setDiploma(diploma);
        this.setNuTijd();
        this.setNederlandsVlaamsDiploma(nederlandsVlaamsDiploma);
    }

    public boolean isNederlandsVlaamsDiploma() {
        return nederlandsVlaamsDiploma;
    }

    public void setNederlandsVlaamsDiploma(boolean nederlandsVlaamsDiploma) {
        this.nederlandsVlaamsDiploma = nederlandsVlaamsDiploma;
    }

    public void setNr(int nr) {
        if(nr < 0) throw new DomainException("Nr van het ticket mag niet onder 0 zijn!");
        this.nr = nr;
    }

    public int getNr() {
        return nr;
    }

    public boolean isVoorinschrijving() {
        return voorinschrijving;
    }

    public Type getType() {
        return type;
    }

    public Diploma getDiploma() {
        return diploma;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        if(student == null) throw new DomainException("Student mag niet leeg zijn!");
        this.student = student;
    }

    public void setVoorinschrijving(boolean voorinschrijving) {
        this.voorinschrijving = voorinschrijving;
    }

    public void setType(Type type) {
        if(type == null) throw new DomainException("Type van opleiding mag niet leeg zijn!");
        this.type = type;
    }

    public void setDiploma(Diploma diploma) {
        if(diploma == null) throw new DomainException("Diploma mag niet leeg zijn!");
        this.diploma = diploma;
    }

    public String getTijd(){
        return tijd;
    }

    public void setNuTijd(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
        this.tijd = LocalTime.now().format(dtf);
    }

    public void setTijd(String tijd){
        this.tijd = tijd;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "nr=" + nr +
                ", voorinschrijving=" + voorinschrijving +
                ", type=" + type.toString() +
                ", diploma=" + diploma.toString() +
                ", student=" + student +
                ", tijd='" + tijd + '\'' +
                ", nederlandsVlaamsDiploma=" + nederlandsVlaamsDiploma +
                '}';
    }
}
