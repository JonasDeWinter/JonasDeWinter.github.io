package ucll.project.domain.ticket;

import ucll.project.db.InMemoryTicketDB;
import ucll.project.db.TicketDb;
import ucll.project.db.TicketDbSql;
import ucll.project.domain.DomainException;
import ucll.project.domain.student.Student;
import ucll.project.ui.controller.Controller;
import ucll.project.ui.controller.ControllerException;

import java.util.ArrayList;
import java.util.List;

public class TicketService {

    private TicketDb database;

    public TicketService(){
        this.database = new TicketDbSql();
    }

    public int getVolgendeNr(){
        return database.getVolgendeNr();
    }

    public void create(Ticket ticket){
        try {
            database.addToTicketlist(ticket);
        }
        catch (Exception exception){
            throw new DomainException(exception.getMessage());
        }
    }

    public Ticket getVolgendeTicket(){
        return database.getVolgendeTicket();
    }

    public List<Ticket> getTickets(){
        return database.getTickets();
    }

    public List<Ticket> getTicketsEenvoudig(){
        List<Ticket> eenvoudig = new ArrayList<>();
        for(Ticket ticket : getTickets()){
            if(ticket != null){
                if(ticket.isNederlandsVlaamsDiploma()){
                    if(ticket.getDiploma() != Diploma.ANDERE && ticket.getType() != Type.ANDERE){
                        eenvoudig.add(ticket);
                    }
                }
            }
        }
        return eenvoudig;
    }

    public List<Ticket> getTicketsComplex(){
        List<Ticket> complex = new ArrayList<>();
        for(Ticket ticket : getTickets()){
            if(ticket != null){
                if(!ticket.isNederlandsVlaamsDiploma()){
                    complex.add(ticket);
                }
                else if(ticket.isNederlandsVlaamsDiploma() && (ticket.getDiploma() == Diploma.ANDERE || ticket.getType() == Type.ANDERE)){
                    complex.add(ticket);
                }
            }
        }
        return complex;
    }

    public Ticket getTicket(int nr){
        if(database.getTicket(nr) == null) throw new DomainException("Ticket bestaat niet!");
        return database.getTicket(nr);
    }

    public Ticket getTicket(Student student){
        if(student == null) throw new DomainException("Student mag niet leeg zijn!");
        List<Ticket> tickets = getTickets();
        Ticket ticket = null;
        for(Ticket t : tickets) {
            if(t.getStudent().equals(student)){
                ticket = t;
                break;
            }
        }
        if(ticket == null) throw new DomainException("Ticket bestaat niet!");
        return ticket;
    }

    public void deleteFromTicketlist(int nr){
        database.deleteFromTicketlist(nr);
    }

}
