package ucll.project.domain.ticket;

public enum Type {
    BACHELOR_GRADUAAT,
    BANABA_POSTGRADUAAT,
    ANDERE
}
