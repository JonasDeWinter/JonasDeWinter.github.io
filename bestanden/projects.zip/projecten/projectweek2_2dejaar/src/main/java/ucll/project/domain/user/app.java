package ucll.project.domain.user;

public class app {
    public static void main(String[] args) {
        UserRepositoryDb a = new UserRepositoryDb();
        User user = new User("vdvMarko", "marko","vdv", "jem@jam.com", Gender.FEMALE,Role.USER);
        a.createUser(user, "dkdkdk");
    }
}
