package ucll.project.ui.controller;

import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.domain.loket.LoketService;
import ucll.project.ui.controller.handlers.PageNotFound;
import ucll.project.ui.controller.handlers.SomethingWentWrong;

public class HandlerFactory {

    public HandlerFactory(){

    }

    public RequestHandler getHandler(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        RequestHandler handler = null;
        try {
            Class handlerClass = Class.forName("ucll.project.ui.controller.handlers." + command);
            Object handlerObject = handlerClass.getConstructor(String.class, UserService.class, TicketService.class, LoketService.class, MedewerkerService.class).newInstance(command, userService, ticketService, loketService, medewerkerService);
            handler = (RequestHandler) handlerObject;
        } catch (ClassNotFoundException e){
            handler = new PageNotFound(command,userService,ticketService, loketService, medewerkerService);
        } catch (Exception e) {
            handler = new SomethingWentWrong(command,userService,ticketService, loketService, medewerkerService);
            System.out.println("Error: " + e.getClass().toString() + "(" + e.getMessage() + ")");
            e.printStackTrace();
        }
        return handler;
    }
}
