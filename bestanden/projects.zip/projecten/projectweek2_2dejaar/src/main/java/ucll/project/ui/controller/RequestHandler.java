package ucll.project.ui.controller;

import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.*;
import ucll.project.domain.loket.LoketService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public abstract class RequestHandler {
    private String command;
    private UserService userService;
    private TicketService ticketService;
    private LoketService loketService;
    private MedewerkerService medewerkerService;

    public RequestHandler(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService){
        setCommand(command);
        setUserService(userService);
        setTicketService(ticketService);
        setLoketService(loketService);
        setMedewerkerService(medewerkerService);
    }

    public LoketService getLoketService(){
        return this.loketService;
    }

    public TicketService getTicketService() {
        return ticketService;
    }

    private void setTicketService(TicketService ticketService) {
        if(ticketService == null) throw new ControllerException("Ticket service can't be null");
        this.ticketService = ticketService;
    }

    private void setLoketService(LoketService loketService){
        if(loketService== null) throw new ControllerException("Loket service can't be null");
        this.loketService = loketService;
    }

    private void setCommand(String command) {
        if (command == null || command.trim().isEmpty()){
            throw new ControllerException("Command is empty");
        }
        this.command = command;
    }

    private void setUserService(UserService userService){
        if (userService == null){
            throw new ControllerException("User service cannot be null.");
        }
        this.userService = userService;
    }

    public UserService getUserService(){ return userService; }

    private void setMedewerkerService(MedewerkerService medewerkerService) {
        if (medewerkerService == null) {
            throw new ControllerException("Medewerker service can't be null");
        }
        this.medewerkerService = medewerkerService;
    }

    public MedewerkerService getMedewerkerService() {
        return this.medewerkerService;
    }

    public abstract String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException;

    public String getCommand() {
        return command;
    }

    void forwardRequest(String destination, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher(destination);
        view.forward(request, response);
    }


}
