package ucll.project.ui.controller.handlers;


import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.AdministratiefMedewerker;
import ucll.project.domain.medewerker.JobStudent;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;

public class CreateMedewerker extends RequestHandler {
    public CreateMedewerker(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        String email = request.getParameter("email");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        Gender gender = Gender.valueOf(request.getParameter("gender"));
        String role = request.getParameter("role");
        String paswoord = request.getParameter("paswoord");

        User x = new User();
        Medewerker mw;
        ArrayList<String> errors = new ArrayList<>();

        try {
            x.setUserName(firstName);
            x.setFirstName(firstName);
            x.setLastName(lastName);
            x.setEmail(email);
            x.setGender(gender);
            x.hashAndSetPassword(paswoord);

        }catch (Exception e){
            errors.add(e.getMessage());
        }

        if(errors.size()>0){
            request.setAttribute("errors",errors);
            return "addMedewerker.jsp";
        }
        else {
            if (role.equals("medewerker")){
                getMedewerkerService().addMedewerker(x);
            }else getMedewerkerService().addStudent(x);
            request.setAttribute("medewerker","Medewerker is aangemaakt");
            return "addMedewerker.jsp";
        }
    }
}
