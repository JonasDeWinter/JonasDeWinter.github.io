package ucll.project.ui.controller.handlers;

import ucll.project.domain.DomainException;
import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.student.Student;
import ucll.project.domain.ticket.Diploma;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.ticket.Type;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class CreateTicketPost extends RequestHandler{

    public CreateTicketPost(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ArrayList<String> errors = new ArrayList<>();
            Student student = new Student();
            this.setStudentEmail(errors,student,request);
            this.setStudentAchternaam(errors,student,request);
            this.setStudentVoornaam(errors,student,request);

            Ticket ticket = new Ticket();
            this.setTicketNr(errors,ticket);
            this.setStudentinTicket(errors,student,ticket,request);
            this.setTicketVoorinschrijving(errors,ticket,request);
            this.setTicketType(errors,ticket,request);
            this.setTicketDiploma(errors,ticket,request);
            this.setNederlandsVlaamsDiploma(errors,ticket,request);
            //this.setTicketTijd(errors,ticket,request);
        if(errors.size() != 0){
            request.setAttribute("errors",errors);
            //response.sendRedirect("createTicket.jsp");
            return "createTicket.jsp";
        }
        try {
            getTicketService().create(ticket);
            request.setAttribute("ticket",getTicketService().getTicket(student));
            return "ticketOverview.jsp";
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
            return "createTicket.jsp";
        }
    }

    private void setNederlandsVlaamsDiploma(ArrayList<String> errors, Ticket ticket, HttpServletRequest request) {
        String taaldiploma = request.getParameter("taaldiploma");
        if (taaldiploma.trim().isEmpty()){
            errors.add("Taal mag niet leeg zijn");
        } else {
            try {
                boolean taal = false;
                if (taaldiploma.equalsIgnoreCase("ja")){
                    taal = true;
                }
                ticket.setNederlandsVlaamsDiploma(taal);
            }
            catch (DomainException exception){
                errors.add(exception.getMessage());
            }
        }
    }

    private void setStudentEmail(ArrayList<String> errors, Student student, HttpServletRequest request){
        String email = request.getParameter("email");
        try {
            student.setEmail(email);
            request.setAttribute("previousEmail",email);
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
        }
    }

    private void setStudentVoornaam(ArrayList<String> errors, Student student, HttpServletRequest request){
        String voornaam = request.getParameter("firstName");
        try {
            student.setVoornaam(voornaam);
            request.setAttribute("previousFirstName",voornaam);
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
        }
    }

    private void setStudentAchternaam(ArrayList<String> errors, Student student, HttpServletRequest request){
        String achternaam = request.getParameter("lastName");
        try {
            student.setAchternaam(achternaam);
            request.setAttribute("previousLastName",achternaam);
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
        }
    }

    private void setStudentinTicket(ArrayList<String> errors, Student student, Ticket ticket, HttpServletRequest request){
        try {
            ticket.setStudent(student);
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
        }
    }

    private void setTicketNr(ArrayList<String> errors, Ticket ticket){
        try{
            int volgende_nummer = getTicketService().getVolgendeNr();
            ticket.setNr(volgende_nummer);
        }
        catch (DomainException exception){
            errors.add(exception.getMessage());
        }
    }

    private void setTicketVoorinschrijving(ArrayList<String> errors, Ticket ticket, HttpServletRequest request){
        String stringvoorinschrijving = request.getParameter("voorinschrijving");

        // Voorinschrijving is nog niet geimplementeerd om één of andere reden

        //if(stringvoorinschrijving.trim().isEmpty()) errors.add("Inschrijving mag niet leeg zijn!");
        //else {
            try {
                boolean voorinschrijving = false;
                //if(stringvoorinschrijving.equals("Ja")) voorinschrijving = true;
                ticket.setVoorinschrijving(voorinschrijving);
            }
            catch (DomainException exception){
                errors.add(exception.getMessage());
            }
        //}
    }

    private void setTicketType(ArrayList<String> errors, Ticket ticket, HttpServletRequest request){
        String stringopleidingstype = request.getParameter("opleidingstype").toUpperCase();
        if(stringopleidingstype == null || stringopleidingstype.trim().isEmpty()) errors.add("Type van opleiding mag niet leeg zijn!");
        else {
            try {
                Type opleidingstype = Type.valueOf(stringopleidingstype);
                ticket.setType(opleidingstype);
            }
            catch (DomainException exception){
                errors.add(exception.getMessage());
            }
        }
    }

    private void setTicketDiploma(ArrayList<String> errors, Ticket ticket, HttpServletRequest request){
        String stringdiploma = request.getParameter("diploma").toUpperCase();
        if(stringdiploma.trim().isEmpty()) errors.add("Diploma mag niet leeg zijn!");
        else {
            try {
                Diploma diploma = Diploma.valueOf(stringdiploma);
                ticket.setDiploma(diploma);
            }
            catch (DomainException exception){
                errors.add(exception.getMessage());
            }
        }
    }



}
