package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.medewerker.MedewerkersStatus;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.User;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

public class LogOut extends RequestHandler {

    public LogOut(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        if(session.getAttribute("user") != null){
            User medewerker = (User) session.getAttribute("user");
            ArrayList<User> medewerkersClockedIn = new ArrayList<>((ArrayList<User>) session.getAttribute("medewerkers"));
            //deleten
            medewerkersClockedIn.remove(medewerker);
            getMedewerkerService().getAlleMedewerkers().get(medewerker.getUserName()).setStatus(MedewerkersStatus.PAUZE); //TODO status niet op pauze?
            // lijst terugzetten
            session.setAttribute("medewerkers", medewerkersClockedIn);
            session.removeAttribute("user");
        }
        return "index.jsp";
    }
}
