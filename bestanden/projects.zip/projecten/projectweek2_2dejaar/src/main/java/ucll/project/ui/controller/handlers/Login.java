package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.medewerker.MedewerkersStatus;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.User;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

public class Login extends RequestHandler {

    public Login(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        Medewerker medewerker;

        if (!username.trim().isEmpty() && !password.trim().isEmpty()) {
            try {
                medewerker = getMedewerkerService().getAlleMedewerkers().get(username);

                //hash password
                User user = new User();
                user.hashAndSetPassword(password);

                if (medewerker.getPersoon().getHashedPassword().equals(user.getHashedPassword())) request.setAttribute("fout", false);
                else throw new NullPointerException();
            } catch (NullPointerException ex) {
                request.setAttribute("previousUsername", username);
                request.setAttribute("fout", true);
                return "login.jsp";
            }
        }
        else {
            request.setAttribute("previousUsername", username);
            request.setAttribute("fout", true);
            return "login.jsp";
        }

        if (session.getAttribute("medewerkers") == null) session.setAttribute("medewerkers", new ArrayList<Medewerker>());

        ArrayList<User> medewerkersClockedIn = new ArrayList<>((ArrayList<User>) session.getAttribute("medewerkers"));

        getMedewerkerService().getAlleMedewerkers().get(medewerker.getPersoon().getUserName()).setStatus(MedewerkersStatus.VRIJ);
        // medewerker aan lijst toevoegen
        medewerkersClockedIn.add(getMedewerkerService().getAlleMedewerkers().get(medewerker.getPersoon().getUserName()).getPersoon()); // niet jobstudent, niet administratief

        session.setAttribute("medewerkers", medewerkersClockedIn);

        session.setAttribute("user", medewerker);

        request.setAttribute("wachtrij", getTicketService().getTickets().size());
        return "WerknemersDashboard.jsp";
    }
}
