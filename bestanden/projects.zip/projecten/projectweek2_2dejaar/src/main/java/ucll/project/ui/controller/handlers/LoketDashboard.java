package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.ControllerException;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LoketDashboard extends RequestHandler {

    public LoketDashboard(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        if(request.getSession().getAttribute("user")==null){
            return "login.jsp";
        }
        HttpSession session = request.getSession();
        Ticket ticket = (Ticket) request.getSession().getAttribute("ticket");
        if(ticket != null){
            request.setAttribute("ticket", ticket);
        }
        return "loket.jsp";
    }
}
