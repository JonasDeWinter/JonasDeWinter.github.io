package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoketOverview extends RequestHandler {

    public LoketOverview(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        if(request.getSession().getAttribute("user")==null){
            return "login.jsp";
        }
        request.setAttribute("loketLijst", getLoketService().getLoketten());
        return "loketOverview.jsp";
    }
}
