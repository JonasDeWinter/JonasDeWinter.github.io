package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SomethingWentWrong extends RequestHandler {

    public SomethingWentWrong(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        return "somethingwentwrong.jsp";
    }
}
