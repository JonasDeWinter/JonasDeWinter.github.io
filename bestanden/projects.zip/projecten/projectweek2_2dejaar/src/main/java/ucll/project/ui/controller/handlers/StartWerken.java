package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.Loket;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.JobStudent;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.medewerker.MedewerkersStatus;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.User;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.ControllerException;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class StartWerken extends RequestHandler {
    public StartWerken(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        Loket loket = getLoketService().getVrijLoket();
        if(loket == null){
            throw new ControllerException("geen vrij loket gevonden");
        }
        HttpSession session = request.getSession();
        if(session.getAttribute("loketNummer") == null){
            session.setAttribute("loketNummer", loket.getNr());
            loket.setBeschikbaar(false);
            loket.setMedewerker((Medewerker) request.getSession().getAttribute("user"));
            loket.getMedewerker().setStatus(MedewerkersStatus.BEZET);
            request.setAttribute("loket", loket.getNr());
        }

        return "loket.jsp";
    }
}
