package ucll.project.ui.controller.handlers;

import ucll.project.domain.DomainException;
import ucll.project.domain.loket.Loket;
import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.medewerker.MedewerkersStatus;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.ControllerException;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sound.sampled.Control;
import java.io.IOException;

public class StopMetWerken extends RequestHandler {
    public StopMetWerken(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        Loket loket = null;
        try {
            loket = getLoketService().getLoket((String) session.getAttribute("loketNummer"));
        } catch (ControllerException | DomainException x) {
            return "index.jsp";
        }
        loket.setBeschikbaar(true);
        loket.getMedewerker().setStatus(MedewerkersStatus.PAUZE);
        loket.verwijderMedewerker();

        session.setAttribute("home", true);
        session.setAttribute("wachtrij", false);
        return "index.jsp";
    }
}
