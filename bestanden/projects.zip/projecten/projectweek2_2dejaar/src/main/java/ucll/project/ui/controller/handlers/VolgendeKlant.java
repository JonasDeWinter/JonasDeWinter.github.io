package ucll.project.ui.controller.handlers;

import ucll.project.domain.loket.LoketService;
import ucll.project.domain.medewerker.AdministratiefMedewerker;
import ucll.project.domain.medewerker.JobStudent;
import ucll.project.domain.medewerker.Medewerker;
import ucll.project.domain.medewerker.MedewerkerService;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.ticket.TicketService;
import ucll.project.domain.user.UserService;
import ucll.project.ui.controller.ControllerException;
import ucll.project.ui.controller.RequestHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.soap.Addressing;
import java.util.List;

public class VolgendeKlant extends RequestHandler {


    public VolgendeKlant(String command, UserService userService, TicketService ticketService, LoketService loketService, MedewerkerService medewerkerService) {
        super(command, userService, ticketService, loketService, medewerkerService);
    }

    @Override
    public String handleRequest(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            Ticket ticket = new Ticket();
            if(session.getAttribute("user") instanceof AdministratiefMedewerker) {
                System.out.println("jobstudent");
                if (getTicketService().getTicketsComplex().size() > 0 ){
                    ticket = getTicketService().getTicketsComplex().get(0);
                    if(getTicketService().getTicketsEenvoudig().size() > 0){
                        List<Ticket> eenvoudiglijst = getTicketService().getTicketsEenvoudig();
                        Ticket eenvoudigticket = eenvoudiglijst.get(0);

                        if(eenvoudigticket.getNr() < ticket.getNr()){
                            ticket = eenvoudigticket;
                        }
                    }
                }else{
                    if(getTicketService().getTicketsEenvoudig().size() > 0){
                        ticket = getTicketService().getTicketsEenvoudig().get(0);
                    }else{
                        throw new ControllerException("er zijn geen wachtende mensen meer");
                    }
                }


            }else if(session.getAttribute("user") instanceof JobStudent){
                System.out.println("jobstudent");
                if(getTicketService().getTicketsEenvoudig().size() > 0){
                    ticket = getTicketService().getTicketsEenvoudig().get(0);
                }else{
                    throw new ControllerException("er zijn geen wachtende mensen meer");
                }
            }

            System.out.println(ticket);
            session.setAttribute("ticket",ticket);
            System.out.println(request.getSession().getAttribute("ticket"));
            request.setAttribute("ticket", request.getSession().getAttribute("ticket"));

            getTicketService().deleteFromTicketlist(ticket.getNr());
            request.setAttribute("fout", false);
            return "loket.jsp";
        } catch (ControllerException ex) {
            request.setAttribute("fout", true);
            return "loket.jsp";
        }

    }
}
