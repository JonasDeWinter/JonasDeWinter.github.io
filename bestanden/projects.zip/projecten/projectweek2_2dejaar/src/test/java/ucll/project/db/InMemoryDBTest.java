package ucll.project.db;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import ucll.project.db.InMemoryTicketDB;
import ucll.project.domain.student.Student;
import ucll.project.domain.ticket.Diploma;
import ucll.project.domain.ticket.Ticket;
import ucll.project.domain.ticket.Type;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

public class InMemoryDBTest {

    private InMemoryTicketDB db = new InMemoryTicketDB();
    User user = new User("Marko", "Marko","beef", "jeam@jaem.com", Gender.MALE, Role.USER);
    Student student = new Student("Marko", "Kosmajac", "leele@dmdm.com");
    Student student2 = new Student("Simon", "germea", "leeaetle@dmaetdm.com");
    Student student3 = new Student("Nick", "aetaet", "leeaettttle@dmeeaetdm.com");
    Student student4 = new Student("Arnaud", "aetry", "arzt@dmaetdm.com");
    Ticket ticket1 = new Ticket(1, student, true, Type.BANABA_POSTGRADUAAT, Diploma.BACHELOR,true);
    Ticket ticket2 = new Ticket(2, student2, true, Type.BANABA_POSTGRADUAAT, Diploma.BACHELOR,false);
    Ticket ticket3 = new Ticket(3, student3, true, Type.BANABA_POSTGRADUAAT, Diploma.BACHELOR,true);
    Ticket ticket4 = new Ticket(700, student4, true, Type.BANABA_POSTGRADUAAT, Diploma.BACHELOR,false);

    @Test
    public void werkt_add_met_ticket_als_parameter(){
        db.addToTicketlist(ticket1);
        assertEquals(1, db.size());
        System.out.println(db.size());
        db.deleteFromTicketlist(ticket1.getNr());
    }

    @Test
    public void werkt_remove_met_ticket_als_parameter(){
        db.addToTicketlist(ticket1);
        System.out.println(db.size());

        db.deleteFromTicketlist(1);
        assertEquals(0, db.size());
        System.out.println(db.size());
    }

    @Test
    public void werkt_removeg_met_ticket_als_parameter(){
        db.addToTicketlist(ticket4);
        db.deleteFromTicketlist(700);
        assertEquals(0, db.size());
        System.out.println(db.size());
    }

    @Test
    public void werkt_getNr_met_ticket_als_parameter(){
        db.addToTicketlist(ticket1);
        System.out.println(db.size());

        assertEquals(2, db.getVolgendeNr());

    }

    @Test
    public void werkt_getTicket_met_nr_als_parameter(){
        db.addToTicketlist(ticket1);
        System.out.println(db.size());

        assertEquals(ticket1,db.getTicket(1));
        System.out.println(db.getTicket(1));
    }

    @Test
    public void werkt_deletefromticketlijst(){
        db.addToTicketlist(ticket1);
        db.addToTicketlist(ticket4);
        db.addToTicketlist(ticket3);

        db.deleteFromTicketlist(700);

        assertEquals(db.getHashMap().get(1),ticket3);
        System.out.println(db.getHashMap());
    }







}
