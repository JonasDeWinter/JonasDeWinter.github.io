package ucll.project.db;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import ucll.project.domain.loket.Loket;
import ucll.project.domain.loket.LoketDBInMemory;
import ucll.project.domain.medewerker.AdministratiefMedewerker;
import ucll.project.domain.student.Student;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

public class LoketDBTest {
    private LoketDBInMemory db = new LoketDBInMemory();
    private User user = new User("Max","Max","vdv","kek@kek.be", Gender.FEMALE, Role.USER);
    private User user1 = new User("Za","M","vggg","kek@kegk.be", Gender.FEMALE, Role.USER);
    private User user2 = new User("xp","ed","vooo","kek@kefk.be", Gender.FEMALE, Role.USER);
    private AdministratiefMedewerker administratiefMedewerker = new AdministratiefMedewerker(user);
    private AdministratiefMedewerker administratiefMedewerker1 = new AdministratiefMedewerker(user1);
    private AdministratiefMedewerker administratiefMedewerker2 = new AdministratiefMedewerker(user2);
    private Loket loket = new Loket("C205",administratiefMedewerker);
    private Loket loket1 = new Loket("C206",administratiefMedewerker1);
    private Loket loket2 = new Loket("C206",administratiefMedewerker2);
    private Student student = new Student("Marko","Kosmajac","keke@keke.bekeke");

    @Test
    public void werkt_addLoket_metLoketAlsParameter(){
        db.getLoketten().clear();
        db.addLoket(loket);
        assertEquals(1, db.size());
        System.out.println(db.toString());
}

    @Test
    public void werkt_getLoket_metNrAlsParameter(){
        db.getLoketten().clear();
        db.addLoket(loket);
        db.addLoket(loket1);
        db.addLoket(loket2);
        assertEquals(loket, db.getLoket("C205"));
    }

    @Test
    public void removeLoketWerktMetLoketAlsParameter(){
        db.getLoketten().clear();
        db.addLoket(loket);
        db.removeLoket(loket);
        assertEquals(0, db.size());
    }

    @Test
    public void werktAddStudentToLoket(){
        db.getLoketten().clear();
        db.addStudentToLoket(student,loket);
        assertEquals(loket.getStudent(),student);
    }

    @Test
    public void werktAddMedewerkerToLoket(){
        db.getLoketten().clear();
        db.addMedewerkerToLoket(administratiefMedewerker, loket);
        assertEquals(loket.getMedewerker(),administratiefMedewerker);
    }

    @Test
    public void werktGetLoketten(){
        db.getLoketten().clear();
        db.addLoket(loket);
        db.addLoket(loket1);
        assertEquals(db.getLoketten().size(),2);
        assertEquals(db.getLoketten().get(1), loket1);
    }

    @Test
    public void werktRemoveStudentFromLoket(){
        db.getLoketten().clear();
        db.addStudentToLoket(student,loket2);
        db.removeStudentFromLoket(loket2);
        assertNull(loket2.getStudent());
    }

    @Test
    public void werktRemoveMedewerkerFromLoket(){
        db.getLoketten().clear();
        db.addMedewerkerToLoket(administratiefMedewerker1,loket2);
        db.removeMedewerkerFromLoket(loket2);
        assertNull(loket2.getMedewerker());
    }


    @Test
    public void getEerstVrijeLoketWerkt(){
        db.getLoketten().clear();
        db.addLoket(loket1);
        db.addLoket(loket2);
        loket1.setBeschikbaar(false);
        loket2.setBeschikbaar(true);
        assertEquals(db.getEerstVrijLoket(), loket2);
    }












}
