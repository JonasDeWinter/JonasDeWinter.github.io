package ucll.project.db.medewerker;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import ucll.project.domain.medewerker.*;
import ucll.project.domain.user.Gender;
import ucll.project.domain.user.Role;
import ucll.project.domain.user.User;

import static org.junit.Assert.*;

public class MedewerkerFactoryTest {

    private MedewerkerFactory medewerkerFactory = new MedewerkerFactory();
    private User u1 = new User("SimonG","Simon","Germeau", "simon.germeau@live.be", Gender.MALE, Role.USER);
    private User u2 = new User("MaxV", "Max", "VandeVelde","aa.aa@aa.aa", Gender.MALE, Role.USER);

    private Medewerker mw1 = new JobStudent(u1);
    private Medewerker mw2 = new AdministratiefMedewerker(u2);


    @Test
    public void createNewStudent() {
        medewerkerFactory.createNewStudent(u1);
        assertEquals(1,medewerkerFactory.getAlleMedewerkers().size());
    }

    @Test
    public void createNewAdministratiefMedewerker() {
        medewerkerFactory.createNewAdministratiefMedewerker(u2);
        assertEquals(1,medewerkerFactory.getAlleMedewerkers().size());
    }

    @Test
    public void getFreeMedewerker() {
        medewerkerFactory.createNewStudent(u1);
        medewerkerFactory.createNewAdministratiefMedewerker(u2);
        assertEquals(u2.getUserName(),medewerkerFactory.getFreeMedewerker().getPersoon().getUserName());
    }

    @Test
    public void getFreeJobstudent() {
        medewerkerFactory.createNewStudent(u1);
        medewerkerFactory.createNewAdministratiefMedewerker(u2);
        assertEquals(u1.getUserName(),medewerkerFactory.getFreeJobstudent().getPersoon().getUserName());
    }

    @Test
    public void getFreeAdministratiefMedewerker() {
        assertEquals("VRIJ", mw2.getStatus().toString());
    }

    @Test
    public void changeMedewerkerStatusNaarPauze() {
        mw2.setStatus(MedewerkersStatus.PAUZE);
        //assertNotEquals("VRIJ", mw2.getStatus().toString());
        //assertNotEquals("BEZET", mw2.getStatus().toString());
        assertEquals("PAUZE", mw2.getStatus().toString());
    }
}