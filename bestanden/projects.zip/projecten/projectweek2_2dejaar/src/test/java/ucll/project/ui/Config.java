package ucll.project.ui;

public class Config {
    public static String BASE_URL="https://dev.marko-zijn-ma.projectweek.be";



}
