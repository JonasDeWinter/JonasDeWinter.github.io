package ucll.project.ui;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ucll.project.db.TicketDbSql;
import ucll.project.domain.ticket.Ticket;

import java.net.MalformedURLException;

import static org.junit.Assert.assertEquals;

public class UsersPageTest {

    private static WebDriver driver;

    @BeforeClass
    public static void SetupDriver() throws MalformedURLException {
        driver = DriverHelper.getDriver();
    }

   /* @Test
    public void FormulierCorrectIngevuldNaarOverview() {
        TicketDbSql ticketDbSql = new TicketDbSql();

        driver.get("http://localhost:8080/Controller?command=CreateTicket");


        WebElement email = driver.findElement(By.id("exampleInputEmail1"));
        String mail = String.valueOf(email);
        email.sendKeys("Testpersoon@testmail.com");

        WebElement firstName = driver.findElement(By.id("exampleVoornaam"));
        String voornaam = String.valueOf(firstName);
        firstName.sendKeys("Tester");

        WebElement lastName = driver.findElement(By.name("lastName"));
        String achternaam = String.valueOf(lastName);
        lastName.sendKeys("Tester");

        WebElement taaldiplomacheck = driver.findElement(By.id("exampleCheck9"));
        taaldiplomacheck.click();

        WebElement diplomaCheck = driver.findElement(By.id("exampleCheck1"));
        diplomaCheck.click();

        WebElement typeOpleidingCheck = driver.findElement(By.id("exampleCheck6"));
        typeOpleidingCheck.click();

        WebElement submitButton = driver.findElement(By.id("submit"));
        submitButton.click();

        Ticket ticket = ticketDbSql.getTicket(voornaam, achternaam, mail);
        ticketDbSql.deleteFromTicketlist(ticket.getNr());


        assertEquals("Ticket", driver.getTitle());

    } */

   /* @Test
    public void FormulierFoutIngevuldBlijfJeOpDezelfdePagina() {
        driver.get("http://localhost:8080/Controller?command=CreateTicket");


        WebElement email = driver.findElement(By.id("exampleInputEmail1"));
        email.sendKeys("Testpersoontestmail.com");

        WebElement firstName = driver.findElement(By.id("exampleVoornaam"));
        firstName.sendKeys("Tester");

        WebElement lastName = driver.findElement(By.name("lastName"));
        lastName.sendKeys("Tester");

        WebElement taaldiplomacheck = driver.findElement(By.id("exampleCheck9"));
        taaldiplomacheck.click();

        WebElement diplomaCheck = driver.findElement(By.id("exampleCheck1"));
        diplomaCheck.click();

        WebElement typeOpleidingCheck = driver.findElement(By.id("exampleCheck6"));
        typeOpleidingCheck.click();

        WebElement submitButton = driver.findElement(By.id("submit"));
        submitButton.click();

        assertEquals("Aanmelden", driver.getTitle());
    }*/


    @AfterClass
    public static void CloseBrowser() {
        // close it in the end, comment this away to keep chrome open
        //driver.close();
    }

    /**
     * This is a sample test, remove this test and write your own!
     */


}
