package ucll.be.taskmanagerpe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskmanagerpeApplication {

    public static void main(String[] args) {

        SpringApplication.run(TaskmanagerpeApplication.class, args);
    }

}
