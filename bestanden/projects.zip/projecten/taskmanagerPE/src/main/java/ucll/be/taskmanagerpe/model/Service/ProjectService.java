package ucll.be.taskmanagerpe.model.Service;

public interface ProjectService {
}
