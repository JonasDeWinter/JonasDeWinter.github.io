package ucll.be.taskmanagerpe.model.Service;

import org.springframework.stereotype.Service;
import ucll.be.taskmanagerpe.model.domain.SubTask;
import ucll.be.taskmanagerpe.model.repository.ProjectRepository;
import ucll.be.taskmanagerpe.model.repository.TaskRepository;

import java.util.ArrayList;
import java.util.HashMap;

@Service
public class ProjectServiceImpl implements ProjectService{

    private ProjectRepository projectRepository;
    private HashMap<Integer, TaskRepository> taken;

    public ProjectServiceImpl(ProjectRepository projectRepository){
        this.projectRepository = projectRepository;
        taken = new HashMap<>();
    }

    //addProject met validatie door middel van DTO
}
