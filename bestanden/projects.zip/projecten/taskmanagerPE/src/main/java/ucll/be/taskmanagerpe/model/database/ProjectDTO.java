package ucll.be.taskmanagerpe.model.database;

public class ProjectDTO {
}
