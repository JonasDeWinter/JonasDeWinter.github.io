package ucll.be.taskmanagerpe.model.domain;

import org.hibernate.annotations.ManyToAny;
import org.hibernate.annotations.Proxy;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Proxy(lazy=false)
public class Project {
        @Id
        @GeneratedValue(strategy = GenerationType.AUTO )
        private int id;
        @NotNull
        private String name;
        private List<Task> takenlijst;


        public int getId() {
                return id;
        }

        public void setId(int id) {
                this.id = id;
        }

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }

        public List<Task> getTakenlijst() {
                return takenlijst;
        }

        public void setTakenlijst(List<Task> takenlijst) {
                this.takenlijst = takenlijst;
        }
}
