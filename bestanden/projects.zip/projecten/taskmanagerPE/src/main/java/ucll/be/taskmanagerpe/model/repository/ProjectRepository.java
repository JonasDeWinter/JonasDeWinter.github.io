package ucll.be.taskmanagerpe.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ucll.be.taskmanagerpe.model.domain.Project;

public interface ProjectRepository extends JpaRepository<Project, Integer> {
}
