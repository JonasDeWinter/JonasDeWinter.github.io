function verandertaal(){
    var x = document.getElementById("taal").value;
    window.location.replace('?lang=' + x);
}